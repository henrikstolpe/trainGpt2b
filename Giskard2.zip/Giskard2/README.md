# SoundSignature Finder

An application for finding a sound signature (pattern) inside another sound (WAV files) 
using signal processing techniques, with an optional ML-based approach for finding 
similar signatures.

## Features

- **Cross-correlation based matching**: Find exact or near-exact sound signatures 
  in longer audio files using normalized cross-correlation.
- **Spectrogram-based matching**: Compare spectral fingerprints for more robust matching.
- **ML model (optional)**: Train a scikit-learn neural network to recognize similar 
  sound signatures, even when distorted or transformed.
- **GUI**: Full graphical interface using PySide6 for loading files, running searches, 
  and visualizing results.

## Project Structure

```
soundsig/
  __init__.py          - Package init
  audio_utils.py       - WAV I/O, resampling, normalization
  signal_engine.py     - Cross-correlation and spectrogram matching
  ml_model.py          - Neural network model for signature similarity
  generate_test_audio.py - Generate synthetic WAV test files
  gui.py               - PySide6 GUI application
tests/
  test_audio_utils.py  - Tests for audio utilities
  test_signal_engine.py - Tests for signal processing
  test_ml_model.py     - Tests for ML model
  test_integration.py  - End-to-end integration tests
```

## Usage

### Running the GUI
```bash
python -m soundsig.gui
```

### Running tests
```bash
python -m pytest tests/ -v
```

## Requirements

- Python 3.10+
- See requirements.txt for dependencies
