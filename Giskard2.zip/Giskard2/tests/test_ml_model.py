"""Tests for ML model module."""

import numpy as np
import pytest
import tempfile
import os

from soundsig.ml_model import SignatureMLModel, MLMatchResult
from soundsig.generate_test_audio import (
    generate_beep_pattern, generate_noise, embed_signature,
    generate_sine_wave,
)


@pytest.fixture
def ml_model():
    """Create an ML model instance."""
    return SignatureMLModel(
        sample_rate=22050,
        n_mfcc=13,
        hidden_layers=(64, 32),
        max_iter=200,
    )


@pytest.fixture
def beep_signature():
    """Create a beep pattern signature."""
    return generate_beep_pattern([440, 880, 1320], 0.1, 0.05, 22050)


@pytest.fixture
def background_segments():
    """Create background noise segments for training."""
    np.random.seed(42)
    return [
        generate_noise(3.0, 22050, amplitude=0.05),
        generate_noise(3.0, 22050, amplitude=0.1),
        generate_noise(3.0, 22050, amplitude=0.02),
    ]


class TestTrainingDataGeneration:
    """Test training data generation."""

    def test_generates_correct_shape(self, ml_model, beep_signature, background_segments):
        """Test that training data has correct dimensions."""
        X, y = ml_model.generate_training_data(
            beep_signature, background_segments, n_augmentations=20
        )
        assert X.ndim == 2
        assert X.shape[1] == 26  # 13 means + 13 stds
        assert len(y) == len(X)

    def test_generates_balanced_classes(self, ml_model, beep_signature, background_segments):
        """Test that training data has both positive and negative examples."""
        X, y = ml_model.generate_training_data(
            beep_signature, background_segments, n_augmentations=30
        )
        assert np.sum(y == 1) > 0
        assert np.sum(y == 0) > 0

    def test_positive_examples_count(self, ml_model, beep_signature, background_segments):
        """Test that correct number of positive examples are generated."""
        n_aug = 25
        X, y = ml_model.generate_training_data(
            beep_signature, background_segments, n_augmentations=n_aug
        )
        assert np.sum(y == 1) == n_aug


class TestModelTraining:
    """Test model training."""

    def test_train_returns_metrics(self, ml_model, beep_signature, background_segments):
        """Test that training returns accuracy metrics."""
        metrics = ml_model.train(beep_signature, background_segments, n_augmentations=50)
        
        assert 'accuracy' in metrics
        assert 'n_train' in metrics
        assert 'n_test' in metrics
        assert 0 <= metrics['accuracy'] <= 1.0

    def test_model_is_trained_after_training(self, ml_model, beep_signature, background_segments):
        """Test that is_trained flag is set after training."""
        assert not ml_model.is_trained
        ml_model.train(beep_signature, background_segments, n_augmentations=50)
        assert ml_model.is_trained

    def test_training_achieves_reasonable_accuracy(self, ml_model, beep_signature, background_segments):
        """Test that the model achieves at least 70% accuracy."""
        metrics = ml_model.train(beep_signature, background_segments, n_augmentations=100)
        assert metrics['accuracy'] >= 0.7


class TestModelPrediction:
    """Test model prediction."""

    def test_predict_before_training_raises(self, ml_model, beep_signature):
        """Test that predicting before training raises RuntimeError."""
        with pytest.raises(RuntimeError):
            ml_model.predict(np.zeros(22050), len(beep_signature))

    def test_predict_detects_embedded_signature(self, ml_model, beep_signature, background_segments):
        """Test that trained model detects an embedded signature."""
        ml_model.train(beep_signature, background_segments, n_augmentations=100)
        
        # Create haystack with signature at known position
        haystack = generate_noise(5.0, 22050, amplitude=0.02)
        position = int(2.0 * 22050)
        haystack = embed_signature(haystack, beep_signature, position)
        
        results = ml_model.predict(
            haystack, len(beep_signature), threshold=0.5
        )
        
        # Should find at least one detection
        assert len(results) >= 1
        
        # Best detection should be near position 2.0s
        best = max(results, key=lambda r: r.probability)
        assert abs(best.position_seconds - 2.0) < 0.5

    def test_predict_low_detections_in_noise(self, ml_model, beep_signature, background_segments):
        """Test that noise-only audio produces few high-confidence detections."""
        ml_model.train(beep_signature, background_segments, n_augmentations=100)
        
        np.random.seed(999)
        noise = generate_noise(3.0, 22050, amplitude=0.05)
        
        results = ml_model.predict(noise, len(beep_signature), threshold=0.8)
        # Should have few or no high-confidence false positives
        assert len(results) <= 3


class TestModelSaveLoad:
    """Test model save/load functionality."""

    def test_save_load_roundtrip(self, ml_model, beep_signature, background_segments):
        """Test that saving and loading preserves model state."""
        ml_model.train(beep_signature, background_segments, n_augmentations=50)
        
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "model.pkl")
            ml_model.save(path)
            
            loaded = SignatureMLModel()
            loaded.load(path)
            
            assert loaded.is_trained
            assert loaded.sample_rate == ml_model.sample_rate
            assert loaded.n_mfcc == ml_model.n_mfcc

    def test_save_untrained_raises(self, ml_model):
        """Test that saving untrained model raises RuntimeError."""
        with pytest.raises(RuntimeError):
            ml_model.save("test.pkl")

    def test_load_nonexistent_raises(self, ml_model):
        """Test that loading nonexistent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            ml_model.load("nonexistent.pkl")

    def test_loaded_model_predicts_same(self, ml_model, beep_signature, background_segments):
        """Test that loaded model makes same predictions as original."""
        ml_model.train(beep_signature, background_segments, n_augmentations=50)
        
        test_audio = generate_noise(2.0, 22050, amplitude=0.02)
        test_audio = embed_signature(test_audio, beep_signature, int(0.5 * 22050))
        
        original_results = ml_model.predict(test_audio, len(beep_signature), threshold=0.3)
        
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "model.pkl")
            ml_model.save(path)
            
            loaded = SignatureMLModel()
            loaded.load(path)
            loaded_results = loaded.predict(test_audio, len(beep_signature), threshold=0.3)
        
        # Same number of detections
        assert len(original_results) == len(loaded_results)
