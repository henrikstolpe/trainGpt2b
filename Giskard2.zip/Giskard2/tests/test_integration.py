"""Integration tests - end-to-end workflows."""

import numpy as np
import pytest
import tempfile
import os

from soundsig.audio_utils import load_wav, save_wav
from soundsig.signal_engine import SignalEngine
from soundsig.ml_model import SignatureMLModel
from soundsig.generate_test_audio import (
    create_test_audio_files, generate_beep_pattern, generate_noise,
    embed_signature,
)


@pytest.fixture
def test_audio_dir():
    """Create test audio files in a temporary directory."""
    with tempfile.TemporaryDirectory() as td:
        metadata = create_test_audio_files(td)
        yield td, metadata


class TestEndToEndCrossCorrelation:
    """End-to-end tests using cross-correlation matching."""

    def test_full_workflow_beep_search(self, test_audio_dir):
        """Test complete workflow: load files, search, find matches."""
        audio_dir, meta = test_audio_dir
        
        # Load signature and haystack
        sig_data, sig_sr = load_wav(meta['signature_beep']['path'])
        hay_data, hay_sr = load_wav(meta['haystack_with_beep']['path'])
        
        assert sig_sr == hay_sr  # Same sample rate
        
        # Search
        engine = SignalEngine(sample_rate=sig_sr)
        matches = engine.find_matches(hay_data, sig_data, threshold=0.5)
        
        # Verify we find the expected positions
        expected_positions = meta['haystack_with_beep']['signature_positions_seconds']
        assert len(matches) >= len(expected_positions)
        
        matched_times = sorted([m.position_seconds for m in matches])
        for expected in expected_positions:
            found = any(abs(mt - expected) < 0.05 for mt in matched_times)
            assert found, f"Expected match near {expected}s not found"

    def test_full_workflow_chirp_search(self, test_audio_dir):
        """Test chirp signature search workflow."""
        audio_dir, meta = test_audio_dir
        
        sig_data, sig_sr = load_wav(meta['signature_chirp']['path'])
        hay_data, hay_sr = load_wav(meta['haystack_with_chirp']['path'])
        
        engine = SignalEngine(sample_rate=sig_sr)
        matches = engine.find_matches(hay_data, sig_data, threshold=0.5)
        
        expected = meta['haystack_with_chirp']['signature_positions_seconds']
        assert len(matches) >= len(expected)

    def test_no_false_positives_in_noise(self, test_audio_dir):
        """Test that noise-only haystack produces no matches."""
        audio_dir, meta = test_audio_dir
        
        sig_data, sig_sr = load_wav(meta['signature_beep']['path'])
        noise_data, _ = load_wav(meta['haystack_noise_only']['path'])
        
        engine = SignalEngine(sample_rate=sig_sr)
        matches = engine.find_matches(noise_data, sig_data, threshold=0.7)
        assert len(matches) == 0


class TestEndToEndSpectrogram:
    """End-to-end tests using spectrogram matching."""

    def test_spectrogram_workflow(self, test_audio_dir):
        """Test spectrogram-based search workflow."""
        audio_dir, meta = test_audio_dir
        
        sig_data, sig_sr = load_wav(meta['signature_chirp']['path'])
        hay_data, hay_sr = load_wav(meta['haystack_with_chirp']['path'])
        
        engine = SignalEngine(sample_rate=sig_sr)
        matches = engine.spectrogram_match(hay_data, sig_data, threshold=0.3)
        
        assert len(matches) >= 1


class TestEndToEndML:
    """End-to-end tests using ML model."""

    def test_ml_train_and_search(self, test_audio_dir):
        """Test full ML workflow: generate data, train, predict."""
        audio_dir, meta = test_audio_dir
        
        sig_data, sig_sr = load_wav(meta['signature_beep']['path'])
        noise_data, _ = load_wav(meta['haystack_noise_only']['path'])
        
        # Train model
        model = SignatureMLModel(
            sample_rate=sig_sr,
            hidden_layers=(64, 32),
            max_iter=200,
        )
        
        bg_segments = [noise_data[:sig_sr * 3], noise_data[sig_sr * 3:sig_sr * 6]]
        metrics = model.train(sig_data, bg_segments, n_augmentations=80)
        
        assert metrics['accuracy'] >= 0.6
        
        # Search in haystack with known signature
        hay_data, _ = load_wav(meta['haystack_with_beep']['path'])
        results = model.predict(hay_data, len(sig_data), threshold=0.5)
        
        # Should find at least one match
        assert len(results) >= 1

    def test_ml_save_load_predict(self, test_audio_dir):
        """Test saving, loading, and predicting with ML model."""
        audio_dir, meta = test_audio_dir
        
        sig_data, sig_sr = load_wav(meta['signature_beep']['path'])
        noise_data, _ = load_wav(meta['haystack_noise_only']['path'])
        
        model = SignatureMLModel(
            sample_rate=sig_sr,
            hidden_layers=(64, 32),
            max_iter=200,
        )
        bg_segments = [noise_data[:sig_sr * 3]]
        model.train(sig_data, bg_segments, n_augmentations=50)
        
        # Save and load
        model_path = os.path.join(audio_dir, "test_model.pkl")
        model.save(model_path)
        
        loaded = SignatureMLModel()
        loaded.load(model_path)
        
        # Predict with loaded model
        hay_data, _ = load_wav(meta['haystack_with_beep']['path'])
        results = loaded.predict(hay_data, len(sig_data), threshold=0.3)
        assert len(results) >= 1


class TestTestAudioGeneration:
    """Test the test audio generation utilities."""

    def test_all_files_created(self, test_audio_dir):
        """Test that all expected test audio files are created."""
        audio_dir, meta = test_audio_dir
        
        # Original core keys that must always exist
        required_keys = [
            'signature_beep', 'signature_chirp',
            'signature_complex', 'signature_drum',
            'haystack_with_beep', 'haystack_with_chirp',
            'haystack_noise_only', 'haystack_rich_noise_only',
            'haystack_multiple',
        ]
        for key in required_keys:
            assert key in meta, f"Missing metadata key: {key}"

        # Hard / adversarial keys
        hard_keys = [
            'haystack_beep_low_amp', 'haystack_chirp_distorted',
            'haystack_complex_reverb', 'haystack_drum_shifted',
            'haystack_beep_adversarial', 'haystack_complex_adversarial',
        ]
        for key in hard_keys:
            assert key in meta, f"Missing hard metadata key: {key}"

    def test_files_are_loadable(self, test_audio_dir):
        """Test that all generated files can be loaded."""
        audio_dir, meta = test_audio_dir
        
        for key, info in meta.items():
            if 'path' in info:
                data, sr = load_wav(info['path'])
                assert len(data) > 0
                assert sr == 22050
