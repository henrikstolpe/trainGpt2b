"""Tests for signal_engine module."""

import numpy as np
import pytest
import sys
import os

from soundsig.signal_engine import SignalEngine, MatchResult
from soundsig.generate_test_audio import (
    generate_sine_wave, generate_chirp, generate_noise,
    generate_silence, generate_beep_pattern, embed_signature,
)


@pytest.fixture
def engine():
    """Create a SignalEngine instance."""
    return SignalEngine(sample_rate=22050)


@pytest.fixture
def beep_signature():
    """Create a beep pattern signature."""
    return generate_beep_pattern([440, 880, 1320], 0.1, 0.05, 22050)


@pytest.fixture
def chirp_signature():
    """Create a chirp signature."""
    return generate_chirp(200, 2000, 0.3, 22050)


class TestCrossCorrelation:
    """Test cross-correlation functionality."""

    def test_identical_signals_perfect_correlation(self, engine):
        """Test that correlating a signal with itself gives correlation ~1.0."""
        sig = generate_sine_wave(440, 0.5, 22050)
        corr = engine.cross_correlate(sig, sig)
        assert corr[0] == pytest.approx(1.0, abs=0.01)

    def test_embedded_signal_detected(self, engine, beep_signature):
        """Test that an embedded signature produces high correlation at correct position."""
        background = generate_noise(5.0, 22050, amplitude=0.01)
        position = int(2.0 * 22050)
        haystack = embed_signature(background, beep_signature, position)
        
        corr = engine.cross_correlate(haystack, beep_signature)
        peak_pos = np.argmax(corr)
        
        # Peak should be near the embedded position
        assert abs(peak_pos - position) < 100  # Within ~4.5ms tolerance
        assert corr[peak_pos] > 0.8

    def test_no_signal_low_correlation(self, engine, beep_signature):
        """Test that noise-only produces low correlation."""
        np.random.seed(123)
        noise = generate_noise(5.0, 22050, amplitude=0.1)
        corr = engine.cross_correlate(noise, beep_signature)
        assert np.max(corr) < 0.3

    def test_needle_longer_than_haystack_raises(self, engine):
        """Test that needle > haystack raises ValueError."""
        short = np.zeros(100)
        long = np.zeros(200)
        with pytest.raises(ValueError):
            engine.cross_correlate(short, long)

    def test_empty_signal_raises(self, engine):
        """Test that empty signals raise ValueError."""
        with pytest.raises(ValueError):
            engine.cross_correlate(np.array([]), np.array([1.0]))

    def test_correlation_output_bounded(self, engine):
        """Test that correlation values are in [-1, 1]."""
        sig1 = generate_sine_wave(440, 1.0, 22050)
        sig2 = generate_sine_wave(440, 0.2, 22050)
        corr = engine.cross_correlate(sig1, sig2)
        assert np.all(corr >= -1.0 - 1e-6)
        assert np.all(corr <= 1.0 + 1e-6)


class TestFindMatches:
    """Test the find_matches method."""

    def test_finds_single_match(self, engine, beep_signature):
        """Test finding a single embedded signature."""
        background = generate_noise(5.0, 22050, amplitude=0.01)
        position = int(2.0 * 22050)
        haystack = embed_signature(background, beep_signature, position)
        
        matches = engine.find_matches(haystack, beep_signature, threshold=0.5)
        assert len(matches) >= 1
        
        best = matches[0]
        assert abs(best.position_seconds - 2.0) < 0.02
        assert best.confidence > 0.5

    def test_finds_multiple_matches(self, engine, beep_signature):
        """Test finding multiple embedded signatures."""
        background = generate_noise(10.0, 22050, amplitude=0.01)
        positions = [int(1.0 * 22050), int(4.0 * 22050), int(7.0 * 22050)]
        haystack = background.copy()
        for pos in positions:
            haystack = embed_signature(haystack, beep_signature, pos)
        
        matches = engine.find_matches(haystack, beep_signature, threshold=0.5)
        assert len(matches) >= 3
        
        matched_times = sorted([m.position_seconds for m in matches])
        expected_times = [1.0, 4.0, 7.0]
        for mt, et in zip(matched_times[:3], expected_times):
            assert abs(mt - et) < 0.05

    def test_no_match_when_absent(self, engine, beep_signature):
        """Test that no matches are found when signature is absent."""
        np.random.seed(456)
        noise = generate_noise(5.0, 22050, amplitude=0.1)
        matches = engine.find_matches(noise, beep_signature, threshold=0.7)
        assert len(matches) == 0

    def test_match_result_has_correct_fields(self, engine, beep_signature):
        """Test that MatchResult has all expected fields."""
        background = generate_noise(3.0, 22050, amplitude=0.01)
        haystack = embed_signature(background, beep_signature, int(1.0 * 22050))
        
        matches = engine.find_matches(haystack, beep_signature, threshold=0.3)
        assert len(matches) > 0
        
        m = matches[0]
        assert isinstance(m.position_samples, int)
        assert isinstance(m.position_seconds, float)
        assert isinstance(m.confidence, float)
        assert isinstance(m.duration_seconds, float)
        assert 0 <= m.confidence <= 1.0


class TestSpectrogramMatch:
    """Test spectrogram-based matching."""

    def test_spectrogram_finds_embedded_chirp(self, engine, chirp_signature):
        """Test spectrogram matching finds an embedded chirp."""
        background = generate_noise(5.0, 22050, amplitude=0.01)
        position = int(2.0 * 22050)
        haystack = embed_signature(background, chirp_signature, position)
        
        matches = engine.spectrogram_match(
            haystack, chirp_signature, threshold=0.3
        )
        assert len(matches) >= 1
        
        best = matches[0]
        # Spectrogram matching has lower temporal resolution
        assert abs(best.position_seconds - 2.0) < 0.2

    def test_spectrogram_no_match_in_noise(self, engine, chirp_signature):
        """Test that spectrogram matching returns no matches for noise."""
        np.random.seed(789)
        noise = generate_noise(5.0, 22050, amplitude=0.1)
        matches = engine.spectrogram_match(noise, chirp_signature, threshold=0.7)
        assert len(matches) == 0


class TestFeatureExtraction:
    """Test feature extraction for ML pipeline."""

    def test_extract_features_shape(self, engine):
        """Test MFCC feature extraction produces correct shape."""
        audio = generate_sine_wave(440, 1.0, 22050)
        mfccs = engine.extract_features(audio, n_mfcc=13)
        assert mfccs.shape[0] == 13
        assert mfccs.shape[1] > 0

    def test_extract_feature_vector_shape(self, engine):
        """Test feature vector extraction produces correct size."""
        audio = generate_sine_wave(440, 0.5, 22050)
        vec = engine.extract_feature_vector(audio, n_mfcc=13)
        assert vec.shape == (26,)  # 13 means + 13 stds

    def test_different_signals_different_features(self, engine):
        """Test that different signals produce different feature vectors."""
        sig1 = generate_sine_wave(440, 0.5, 22050)
        sig2 = generate_noise(0.5, 22050, amplitude=0.5)
        
        vec1 = engine.extract_feature_vector(sig1)
        vec2 = engine.extract_feature_vector(sig2)
        
        assert not np.allclose(vec1, vec2)


class TestComputeSpectrogram:
    """Test spectrogram computation."""

    def test_spectrogram_shape(self, engine):
        """Test spectrogram has correct dimensions."""
        audio = generate_sine_wave(440, 1.0, 22050)
        freqs, times, spec = engine.compute_spectrogram(audio)
        
        assert len(freqs) > 0
        assert len(times) > 0
        assert spec.shape == (len(freqs), len(times))

    def test_spectrogram_nonnegative(self, engine):
        """Test spectrogram values are non-negative."""
        audio = generate_sine_wave(440, 1.0, 22050)
        _, _, spec = engine.compute_spectrogram(audio)
        assert np.all(spec >= 0)
