"""Comparison tests — ML model vs. DSP methods on degraded / adversarial audio.

These tests generate haystack files with distorted, low-amplitude, and
reverbed signatures, then run all three search methods (cross-correlation,
spectrogram, ML) and assert that the ML model recovers more true positives
in the hard cases, quantifying the comparative advantage.
"""

import numpy as np
import pytest
import tempfile

from soundsig.signal_engine import SignalEngine
from soundsig.ml_model import SignatureMLModel
from soundsig.generate_test_audio import (
    generate_beep_pattern,
    generate_chirp,
    generate_complex_signature,
    generate_drum_signature,
    generate_noise,
    generate_pink_noise,
    generate_rich_background,
    embed_signature,
    distort_clip,
    distort_lowpass,
    distort_highpass,
    distort_reverb,
    distort_pitch_shift,
    distort_time_stretch,
)

SR = 22050


# ======================================================================
# Helpers
# ======================================================================

def _count_hits(match_results, expected_seconds, tolerance=0.3):
    """Count how many expected positions were found by a set of results.

    Args:
        match_results: List of MatchResult or MLMatchResult.
        expected_seconds: List of expected match times.
        tolerance: Acceptable distance (seconds).

    Returns:
        Number of expected positions detected.
    """
    result_times = [getattr(m, 'position_seconds', 0.0) for m in match_results]
    hits = 0
    for exp in expected_seconds:
        if any(abs(rt - exp) < tolerance for rt in result_times):
            hits += 1
    return hits


def _train_ml_model(signature, distortion_fn=None, augmentations=200):
    """Train an ML model on a signature with heavy augmentations.

    If *distortion_fn* is given it is applied to every positive example
    during training so the model learns the distorted variant.
    """
    bg_segs = [
        generate_noise(4.0, SR, amplitude=0.05),
        generate_pink_noise(4.0, SR, amplitude=0.08),
        generate_rich_background(4.0, SR, seed=42),
    ]
    model = SignatureMLModel(
        sample_rate=SR,
        hidden_layers=(128, 64, 32),
        max_iter=300,
    )
    # Generate training data manually so we can inject distortions
    if distortion_fn is not None:
        features, labels = [], []
        sig_len = len(signature)
        for _ in range(augmentations):
            gain = np.random.uniform(0.05, 1.2)
            noise_lvl = np.random.choice([0.0, 0.02, 0.05, 0.1, 0.15])
            aug = signature * gain
            aug = distortion_fn(aug)
            if noise_lvl > 0:
                aug += noise_lvl * np.random.randn(sig_len)
            feat = model._extract_window_features(aug)
            features.append(feat)
            labels.append(1)
        for bg in bg_segs:
            n_win = augmentations // len(bg_segs)
            for _ in range(n_win):
                start = np.random.randint(0, len(bg) - sig_len)
                feat = model._extract_window_features(bg[start:start + sig_len])
                features.append(feat)
                labels.append(0)
        X, y = np.array(features), np.array(labels)
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import accuracy_score
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2,
                                                    random_state=42,
                                                    stratify=y)
        X_tr = model.scaler.fit_transform(X_tr)
        X_te = model.scaler.transform(X_te)
        model.model.fit(X_tr, y_tr)
        model.is_trained = True
    else:
        model.train(signature, bg_segs, n_augmentations=augmentations)
    return model


# ======================================================================
# Fixtures
# ======================================================================

@pytest.fixture
def engine():
    return SignalEngine(sample_rate=SR)


@pytest.fixture
def beep_sig():
    return generate_beep_pattern([440, 880, 1320], 0.1, 0.05, SR)


@pytest.fixture
def chirp_sig():
    return generate_chirp(200, 2000, 0.3, SR)


@pytest.fixture
def complex_sig():
    return generate_complex_signature(SR)


@pytest.fixture
def drum_sig():
    return generate_drum_signature(SR)


# ======================================================================
# Test class: Low-amplitude signatures
# ======================================================================

class TestLowAmplitude:
    """Signatures embedded at very low gain in a noisy background."""

    def test_beep_low_amp_ml_finds_more(self, engine, beep_sig):
        """ML should detect low-amplitude beeps; xcorr may also do well here.

        For undistorted signatures at low amplitude, xcorr can still excel,
        so we only assert ML finds at least 2 of 3.  The distortion tests
        are where ML's advantage is decisive.
        """
        np.random.seed(10)
        bg = generate_rich_background(12.0, SR, seed=10)
        positions_sec = [1.5, 5.0, 9.0]
        gains = [0.12, 0.10, 0.15]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, beep_sig, pos, gain=g)

        # Cross-correlation
        xcorr_matches = engine.find_matches(haystack, beep_sig, threshold=0.3)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)

        # ML (trained with aggressive gain-lowering augmentations)
        ml = _train_ml_model(beep_sig, augmentations=250)
        ml_matches = ml.predict(haystack, len(beep_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        # ML should find at least 2 of 3 even in this hard scenario
        assert ml_hits >= 2, f"ML only found {ml_hits}/3 low-amplitude beeps"
        # Both methods should be competitive here (undistorted signal)
        assert xcorr_hits >= 2, f"xcorr only found {xcorr_hits}/3"

    def test_complex_low_amp_comparison(self, engine, complex_sig):
        """ML vs spectrogram on a very quiet complex signature."""
        np.random.seed(20)
        bg = generate_rich_background(10.0, SR, seed=20)
        positions_sec = [2.0, 6.5]
        gains = [0.10, 0.08]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, complex_sig, pos, gain=g)

        # Spectrogram
        spec_matches = engine.spectrogram_match(haystack, complex_sig, threshold=0.2)
        spec_hits = _count_hits(spec_matches, positions_sec)

        # ML
        ml = _train_ml_model(complex_sig, augmentations=200)
        ml_matches = ml.predict(haystack, len(complex_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= spec_hits


# ======================================================================
# Test class: Distorted signatures
# ======================================================================

class TestDistortedSignatures:
    """Signatures degraded by clipping, filtering, reverb, or pitch shift."""

    def test_clipped_beep_ml_advantage(self, engine, beep_sig):
        """ML trained on clipped beeps should beat xcorr on clipped haystacks."""
        np.random.seed(30)
        clipped = distort_clip(beep_sig, clip_level=0.3)
        bg = generate_pink_noise(10.0, SR, amplitude=0.06)
        positions_sec = [1.0, 4.5, 8.0]
        gains = [0.25, 0.20, 0.30]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, clipped, pos, gain=g)

        # Xcorr uses the CLEAN signature as template
        xcorr_matches = engine.find_matches(haystack, beep_sig, threshold=0.3)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)

        # ML trained on clipped variant
        distort_fn = lambda s: distort_clip(s, clip_level=0.3)
        ml = _train_ml_model(beep_sig, distortion_fn=distort_fn, augmentations=200)
        ml_matches = ml.predict(haystack, len(beep_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= xcorr_hits, (
            f"ML found {ml_hits}, xcorr found {xcorr_hits} on clipped beeps")

    def test_reverbed_chirp_ml_advantage(self, engine, chirp_sig):
        """ML trained on reverbed chirps should beat spectrogram matching."""
        np.random.seed(40)
        reverbed = distort_reverb(chirp_sig, decay=0.5, delay_ms=25, sample_rate=SR)
        bg = generate_rich_background(12.0, SR, seed=40)
        positions_sec = [2.0, 7.0]
        gains = [0.20, 0.15]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, reverbed, pos, gain=g)

        # Spectrogram uses clean template
        spec_matches = engine.spectrogram_match(haystack, chirp_sig, threshold=0.2)
        spec_hits = _count_hits(spec_matches, positions_sec)

        distort_fn = lambda s: distort_reverb(s, decay=0.5, delay_ms=25, sample_rate=SR)
        ml = _train_ml_model(chirp_sig, distortion_fn=distort_fn, augmentations=200)
        ml_matches = ml.predict(haystack, len(chirp_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= spec_hits

    def test_lowpassed_complex_ml_advantage(self, engine, complex_sig):
        """ML trained on lowpassed complex sig should beat xcorr on muffled audio."""
        np.random.seed(50)
        muffled = distort_lowpass(complex_sig, cutoff_hz=2000, sample_rate=SR)
        bg = generate_rich_background(10.0, SR, seed=50)
        positions_sec = [1.5, 6.0]
        gains = [0.18, 0.14]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, muffled, pos, gain=g)

        xcorr_matches = engine.find_matches(haystack, complex_sig, threshold=0.2)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)

        distort_fn = lambda s: distort_lowpass(s, cutoff_hz=2000, sample_rate=SR)
        ml = _train_ml_model(complex_sig, distortion_fn=distort_fn, augmentations=200)
        ml_matches = ml.predict(haystack, len(complex_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= xcorr_hits

    def test_pitch_shifted_drum_ml_advantage(self, engine, drum_sig):
        """ML on pitch-shifted drums should beat xcorr with original template."""
        np.random.seed(60)
        shifted = distort_pitch_shift(drum_sig, semitones=2.0)
        bg = generate_pink_noise(10.0, SR, amplitude=0.07)
        positions_sec = [2.0, 6.5]
        gains = [0.25, 0.20]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, shifted, pos, gain=g)

        xcorr_matches = engine.find_matches(haystack, drum_sig, threshold=0.2)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)

        distort_fn = lambda s: distort_pitch_shift(s, semitones=2.0)
        ml = _train_ml_model(drum_sig, distortion_fn=distort_fn, augmentations=200)
        ml_matches = ml.predict(haystack, len(drum_sig), threshold=0.4)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= xcorr_hits


# ======================================================================
# Test class: Combined adversarial conditions
# ======================================================================

class TestAdversarial:
    """Multi-distortion + very low amplitude — most challenging scenarios."""

    def test_adversarial_beep_clip_reverb(self, engine, beep_sig):
        """Beep clipped + reverbed + very quiet in rich background."""
        np.random.seed(70)
        degraded = distort_reverb(
            distort_clip(beep_sig, 0.35), decay=0.45, delay_ms=20, sample_rate=SR)
        bg = generate_rich_background(15.0, SR, seed=70)
        positions_sec = [3.0, 9.0]
        gains = [0.08, 0.06]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, degraded, pos, gain=g)

        xcorr_matches = engine.find_matches(haystack, beep_sig, threshold=0.15)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)
        spec_matches = engine.spectrogram_match(haystack, beep_sig, threshold=0.15)
        spec_hits = _count_hits(spec_matches, positions_sec)

        def combo_dist(s):
            return distort_reverb(
                distort_clip(s, 0.35), decay=0.45, delay_ms=20, sample_rate=SR)
        ml = _train_ml_model(beep_sig, distortion_fn=combo_dist, augmentations=300)
        ml_matches = ml.predict(haystack, len(beep_sig), threshold=0.35)
        ml_hits = _count_hits(ml_matches, positions_sec)

        # ML should match or exceed both DSP methods
        dsp_best = max(xcorr_hits, spec_hits)
        assert ml_hits >= dsp_best, (
            f"ML {ml_hits} vs DSP-best {dsp_best} "
            f"(xcorr={xcorr_hits}, spec={spec_hits})")

    def test_adversarial_complex_timestretch_lowpass(self, engine, complex_sig):
        """Complex sig time-stretched + lowpassed + very quiet."""
        np.random.seed(80)
        degraded = distort_lowpass(
            distort_time_stretch(complex_sig, factor=1.08), 2500, SR)
        bg = generate_rich_background(12.0, SR, seed=80)
        positions_sec = [4.0, 8.5]
        gains = [0.07, 0.05]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos, g in zip(positions, gains):
            haystack = embed_signature(haystack, degraded, pos, gain=g)

        xcorr_matches = engine.find_matches(haystack, complex_sig, threshold=0.15)
        xcorr_hits = _count_hits(xcorr_matches, positions_sec)

        def combo_dist(s):
            return distort_lowpass(distort_time_stretch(s, factor=1.08), 2500, SR)
        ml = _train_ml_model(complex_sig, distortion_fn=combo_dist, augmentations=300)
        ml_matches = ml.predict(haystack, len(complex_sig), threshold=0.35)
        ml_hits = _count_hits(ml_matches, positions_sec)

        assert ml_hits >= xcorr_hits


# ======================================================================
# Test class: False-positive resistance
# ======================================================================

class TestFalsePositives:
    """Verify that ML models don't hallucinate matches in noise-only files."""

    def test_ml_no_detections_in_white_noise(self, beep_sig):
        """ML should produce zero or very few high-confidence hits in noise."""
        np.random.seed(90)
        noise = generate_noise(8.0, SR, amplitude=0.1)
        ml = _train_ml_model(beep_sig, augmentations=150)
        ml_matches = ml.predict(noise, len(beep_sig), threshold=0.7)
        assert len(ml_matches) <= 2

    def test_ml_no_detections_in_rich_noise(self, complex_sig):
        """ML should produce few hits in a rich (but signature-free) background."""
        np.random.seed(91)
        bg = generate_rich_background(10.0, SR, seed=91)
        ml = _train_ml_model(complex_sig, augmentations=150)
        ml_matches = ml.predict(bg, len(complex_sig), threshold=0.7)
        assert len(ml_matches) <= 3


# ======================================================================
# Test class: DSP methods on easy cases (sanity check)
# ======================================================================

class TestDSPEasyCases:
    """Cross-correlation and spectrogram should ace the easy haystacks."""

    def test_xcorr_all_easy_beep_hits(self, engine, beep_sig):
        """Xcorr should find all full-amplitude beeps in quiet noise."""
        np.random.seed(100)
        bg = generate_noise(10.0, SR, amplitude=0.02)
        positions_sec = [1.0, 4.0, 7.0]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos in positions:
            haystack = embed_signature(haystack, beep_sig, pos, gain=1.0)

        matches = engine.find_matches(haystack, beep_sig, threshold=0.5)
        hits = _count_hits(matches, positions_sec)
        assert hits == 3

    def test_spectrogram_easy_chirp(self, engine, chirp_sig):
        """Spectrogram should find full-amplitude chirps."""
        np.random.seed(101)
        bg = generate_noise(8.0, SR, amplitude=0.02)
        positions_sec = [1.5, 5.5]
        positions = [int(s * SR) for s in positions_sec]
        haystack = bg.copy()
        for pos in positions:
            haystack = embed_signature(haystack, chirp_sig, pos, gain=1.0)

        matches = engine.spectrogram_match(haystack, chirp_sig, threshold=0.3)
        hits = _count_hits(matches, positions_sec)
        assert hits >= 1  # spectrogram has lower temporal res


# ======================================================================
# Test class: Summary report (prints comparative table — not strict assert)
# ======================================================================

class TestComparisonReport:
    """Generate a human-readable comparison report (always passes)."""

    def test_print_comparison_table(self, engine, beep_sig, complex_sig, capsys):
        """Print a comparison table of hits across methods / difficulty levels."""
        np.random.seed(200)

        scenarios = []

        # Easy beep
        bg_e = generate_noise(10.0, SR, amplitude=0.02)
        posE = [int(2.0*SR), int(6.0*SR)]
        h_e = bg_e.copy()
        for p in posE:
            h_e = embed_signature(h_e, beep_sig, p, gain=1.0)
        scenarios.append(("Easy beep (gain=1.0, white noise)", beep_sig, h_e, [2.0, 6.0], None))

        # Medium beep
        bg_m = generate_pink_noise(10.0, SR, amplitude=0.06)
        posM = [int(2.0*SR), int(6.0*SR)]
        h_m = bg_m.copy()
        for p in posM:
            h_m = embed_signature(h_m, beep_sig, p, gain=0.25)
        scenarios.append(("Med beep (gain=0.25, pink noise)", beep_sig, h_m, [2.0, 6.0], None))

        # Hard beep (clipped + reverbed + low amp)
        degraded = distort_reverb(distort_clip(beep_sig, 0.35), 0.45, 20, SR)
        bg_h = generate_rich_background(10.0, SR, seed=201)
        posH = [int(2.0*SR), int(6.0*SR)]
        h_h = bg_h.copy()
        for p in posH:
            h_h = embed_signature(h_h, degraded, p, gain=0.08)
        def beep_combo(s):
            return distort_reverb(distort_clip(s, 0.35), 0.45, 20, SR)
        scenarios.append(("Hard beep (clip+reverb, gain=0.08, rich bg)", beep_sig, h_h, [2.0, 6.0], beep_combo))

        # Hard complex (lowpass + time-stretch + low amplitude)
        deg_c = distort_lowpass(distort_time_stretch(complex_sig, 1.08), 2500, SR)
        bg_c = generate_rich_background(10.0, SR, seed=202)
        posC = [int(2.0*SR), int(6.0*SR)]
        h_c = bg_c.copy()
        for p in posC:
            h_c = embed_signature(h_c, deg_c, p, gain=0.07)
        def comp_combo(s):
            return distort_lowpass(distort_time_stretch(s, 1.08), 2500, SR)
        scenarios.append(("Hard complex (stretch+LP, gain=0.07, rich bg)", complex_sig, h_c, [2.0, 6.0], comp_combo))

        header = f"\n{'Scenario':<50} {'XCorr':>6} {'Spec':>6} {'ML':>6}  (out of N)"
        lines = [header, "-" * len(header)]

        for label, sig, hay, exp_sec, dist_fn in scenarios:
            n_exp = len(exp_sec)
            # xcorr
            xm = engine.find_matches(hay, sig, threshold=0.2)
            xh = _count_hits(xm, exp_sec)
            # spectrogram
            sm = engine.spectrogram_match(hay, sig, threshold=0.15)
            sh = _count_hits(sm, exp_sec)
            # ML
            ml = _train_ml_model(sig, distortion_fn=dist_fn, augmentations=200)
            mm = ml.predict(hay, len(sig), threshold=0.35)
            mh = _count_hits(mm, exp_sec)

            lines.append(f"{label:<50} {xh:>6} {sh:>6} {mh:>6}  (/{n_exp})")

        report = "\n".join(lines)
        print(report)

        # This test always passes — it's purely informational
        assert True
