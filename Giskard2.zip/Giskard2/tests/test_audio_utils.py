"""Tests for audio_utils module."""

import numpy as np
import pytest
import tempfile
import os
from pathlib import Path

from soundsig.audio_utils import (
    load_wav, save_wav, resample, normalize, trim_silence,
    get_duration, audio_info,
)


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as td:
        yield td


@pytest.fixture
def sample_audio():
    """Create a simple sine wave test signal."""
    sr = 22050
    duration = 1.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    data = 0.5 * np.sin(2 * np.pi * 440 * t)
    return data, sr


class TestSaveAndLoad:
    """Test WAV file save and load operations."""

    def test_save_and_load_roundtrip(self, temp_dir, sample_audio):
        """Test that saving and loading preserves audio data."""
        data, sr = sample_audio
        filepath = os.path.join(temp_dir, "test.wav")
        
        save_wav(filepath, data, sr)
        loaded_data, loaded_sr = load_wav(filepath)
        
        assert loaded_sr == sr
        # WAV uses 16-bit PCM by default, so allow quantization error
        np.testing.assert_allclose(loaded_data, data, atol=1e-4)

    def test_save_creates_directories(self, temp_dir, sample_audio):
        """Test that save_wav creates parent directories."""
        data, sr = sample_audio
        filepath = os.path.join(temp_dir, "subdir", "deep", "test.wav")
        
        save_wav(filepath, data, sr)
        assert os.path.exists(filepath)

    def test_load_nonexistent_file(self):
        """Test that loading a nonexistent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            load_wav("nonexistent_file.wav")

    def test_load_stereo_to_mono(self, temp_dir):
        """Test that stereo files are converted to mono."""
        import soundfile as sf
        sr = 22050
        stereo = np.column_stack([
            np.sin(np.linspace(0, 1, sr)),
            np.cos(np.linspace(0, 1, sr)),
        ])
        filepath = os.path.join(temp_dir, "stereo.wav")
        sf.write(filepath, stereo, sr)
        
        data, loaded_sr = load_wav(filepath)
        assert data.ndim == 1
        assert loaded_sr == sr


class TestResample:
    """Test audio resampling."""

    def test_resample_upsample(self):
        """Test upsampling doubles the number of samples."""
        data = np.sin(np.linspace(0, 2 * np.pi, 100))
        resampled = resample(data, 100, 200)
        assert len(resampled) == 200

    def test_resample_downsample(self):
        """Test downsampling halves the number of samples."""
        data = np.sin(np.linspace(0, 2 * np.pi, 200))
        resampled = resample(data, 200, 100)
        assert len(resampled) == 100

    def test_resample_same_rate(self):
        """Test resampling at same rate returns identical data."""
        data = np.sin(np.linspace(0, 2 * np.pi, 100))
        resampled = resample(data, 100, 100)
        np.testing.assert_array_equal(resampled, data)

    def test_load_with_resampling(self, temp_dir, sample_audio):
        """Test loading with target sample rate triggers resampling."""
        data, sr = sample_audio
        filepath = os.path.join(temp_dir, "test.wav")
        save_wav(filepath, data, sr)
        
        target_sr = 16000
        loaded_data, loaded_sr = load_wav(filepath, target_sr=target_sr)
        assert loaded_sr == target_sr
        expected_len = int(len(data) * target_sr / sr)
        assert len(loaded_data) == expected_len


class TestNormalize:
    """Test audio normalization."""

    def test_normalize_scales_to_unit(self):
        """Test normalization scales peak to 1.0."""
        data = np.array([0.0, 0.25, -0.5, 0.1])
        normed = normalize(data)
        assert np.max(np.abs(normed)) == pytest.approx(1.0)

    def test_normalize_preserves_ratios(self):
        """Test normalization preserves relative amplitudes."""
        data = np.array([0.2, 0.4, -0.8])
        normed = normalize(data)
        assert normed[1] / normed[0] == pytest.approx(2.0)

    def test_normalize_silence(self):
        """Test normalizing silence returns silence."""
        data = np.zeros(100)
        normed = normalize(data)
        np.testing.assert_array_equal(normed, data)


class TestTrimSilence:
    """Test silence trimming."""

    def test_trim_leading_silence(self):
        """Test trimming leading silence."""
        silence = np.zeros(100)
        signal = np.ones(50) * 0.5
        data = np.concatenate([silence, signal])
        trimmed = trim_silence(data, threshold=0.01)
        assert len(trimmed) == 50

    def test_trim_trailing_silence(self):
        """Test trimming trailing silence."""
        signal = np.ones(50) * 0.5
        silence = np.zeros(100)
        data = np.concatenate([signal, silence])
        trimmed = trim_silence(data, threshold=0.01)
        assert len(trimmed) == 50

    def test_trim_both_sides(self):
        """Test trimming silence from both sides."""
        silence = np.zeros(100)
        signal = np.ones(50) * 0.5
        data = np.concatenate([silence, signal, silence])
        trimmed = trim_silence(data, threshold=0.01)
        assert len(trimmed) == 50

    def test_trim_all_silence(self):
        """Test trimming all-silence returns original."""
        data = np.zeros(100)
        trimmed = trim_silence(data, threshold=0.01)
        assert len(trimmed) == len(data)


class TestDurationAndInfo:
    """Test duration calculation and audio info."""

    def test_get_duration(self):
        """Test duration calculation."""
        sr = 22050
        data = np.zeros(sr * 2)  # 2 seconds
        assert get_duration(data, sr) == pytest.approx(2.0)

    def test_audio_info(self, temp_dir, sample_audio):
        """Test audio file info extraction."""
        data, sr = sample_audio
        filepath = os.path.join(temp_dir, "test.wav")
        save_wav(filepath, data, sr)
        
        info = audio_info(filepath)
        assert info['sample_rate'] == sr
        assert info['channels'] == 1
        assert info['duration'] == pytest.approx(1.0, abs=0.01)
