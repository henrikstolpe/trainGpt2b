"""SoundSignature Finder - Find sound signatures inside other sounds."""

__version__ = "1.0.0"
