"""Generate synthetic WAV test files for testing the sound signature finder.

Creates various test audio files with known signatures embedded at known positions,
with configurable distortion, noise levels, and backgrounds to enable rigorous
comparison testing between cross-correlation, spectrogram, and ML-based search methods.
"""

import numpy as np
from pathlib import Path
from typing import List, Tuple, Optional
from scipy.signal import butter, lfilter, resample as scipy_resample

from . import audio_utils


# ============================================================================
# Basic waveform generators
# ============================================================================

def generate_sine_wave(
    frequency: float,
    duration: float,
    sample_rate: int = 22050,
    amplitude: float = 0.8,
) -> np.ndarray:
    """Generate a sine wave."""
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return amplitude * np.sin(2 * np.pi * frequency * t)


def generate_chirp(
    f_start: float,
    f_end: float,
    duration: float,
    sample_rate: int = 22050,
    amplitude: float = 0.8,
) -> np.ndarray:
    """Generate a linear chirp (frequency sweep)."""
    from scipy.signal import chirp as scipy_chirp
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return amplitude * scipy_chirp(t, f_start, duration, f_end)


def generate_noise(
    duration: float,
    sample_rate: int = 22050,
    amplitude: float = 0.1,
) -> np.ndarray:
    """Generate white noise."""
    n_samples = int(sample_rate * duration)
    return amplitude * np.random.randn(n_samples)


def generate_pink_noise(
    duration: float,
    sample_rate: int = 22050,
    amplitude: float = 0.1,
) -> np.ndarray:
    """Generate pink (1/f) noise — more realistic background than white noise."""
    n_samples = int(sample_rate * duration)
    white = np.random.randn(n_samples)
    # Simple 1/f approximation via cumulative filter
    fft = np.fft.rfft(white)
    freqs = np.fft.rfftfreq(n_samples, 1.0 / sample_rate)
    freqs[0] = 1.0  # avoid div by zero
    fft /= np.sqrt(freqs)
    pink = np.fft.irfft(fft, n=n_samples)
    pink = pink / (np.max(np.abs(pink)) + 1e-10) * amplitude
    return pink


def generate_silence(duration: float, sample_rate: int = 22050) -> np.ndarray:
    """Generate silence."""
    return np.zeros(int(sample_rate * duration))


def generate_beep_pattern(
    frequencies: List[float],
    beep_duration: float = 0.1,
    gap_duration: float = 0.05,
    sample_rate: int = 22050,
) -> np.ndarray:
    """Generate a pattern of beeps at different frequencies."""
    parts = []
    for i, freq in enumerate(frequencies):
        parts.append(generate_sine_wave(freq, beep_duration, sample_rate))
        if i < len(frequencies) - 1:
            parts.append(generate_silence(gap_duration, sample_rate))
    return np.concatenate(parts)


def generate_complex_signature(sample_rate: int = 22050) -> np.ndarray:
    """Generate a more complex, musically-rich signature.
    
    Five-tone ascending arpeggio with harmonics and an AM envelope — much more
    distinctive than a simple beep pattern.
    """
    freqs = [330, 440, 554, 659, 880]  # A-minor arpeggio
    note_dur = 0.08
    gap_dur = 0.02
    parts = []
    for i, f in enumerate(freqs):
        t = np.linspace(0, note_dur, int(sample_rate * note_dur), endpoint=False)
        # fundamental + harmonics
        tone = 0.6 * np.sin(2 * np.pi * f * t)
        tone += 0.25 * np.sin(2 * np.pi * 2 * f * t)
        tone += 0.15 * np.sin(2 * np.pi * 3 * f * t)
        # AM envelope (fade in/out)
        envelope = np.sin(np.pi * t / note_dur) ** 0.5
        parts.append(tone * envelope)
        if i < len(freqs) - 1:
            parts.append(generate_silence(gap_dur, sample_rate))
    return np.concatenate(parts)


def generate_drum_signature(sample_rate: int = 22050) -> np.ndarray:
    """Generate a percussive drum-like signature (kick-snare-kick pattern).
    
    Uses exponentially decaying noise bursts at different frequency bands.
    """
    def drum_hit(dur, low_f, high_f, sr):
        n = int(sr * dur)
        t = np.linspace(0, dur, n, endpoint=False)
        noise = np.random.randn(n)
        # Bandpass filter
        nyq = sr / 2
        b, a = butter(4, [max(low_f, 20) / nyq, min(high_f, nyq - 1) / nyq], btype='band')
        filtered = lfilter(b, a, noise)
        envelope = np.exp(-t * 15)  # fast decay
        return filtered * envelope * 0.8

    sr = sample_rate
    kick = drum_hit(0.1, 40, 200, sr)
    snare = drum_hit(0.08, 200, 5000, sr)
    gap = generate_silence(0.04, sr)
    return np.concatenate([kick, gap, snare, gap, kick])


# ============================================================================
# Distortion / degradation functions
# ============================================================================

def distort_clip(signal: np.ndarray, clip_level: float = 0.3) -> np.ndarray:
    """Hard-clip a signal, simulating amplifier overdrive."""
    return np.clip(signal, -clip_level, clip_level)


def distort_lowpass(signal: np.ndarray, cutoff_hz: float = 2000.0,
                    sample_rate: int = 22050) -> np.ndarray:
    """Apply a low-pass filter (like a muffled/telephone effect)."""
    nyq = sample_rate / 2
    b, a = butter(4, min(cutoff_hz, nyq - 1) / nyq, btype='low')
    return lfilter(b, a, signal)


def distort_highpass(signal: np.ndarray, cutoff_hz: float = 500.0,
                     sample_rate: int = 22050) -> np.ndarray:
    """Apply a high-pass filter (tinny sound)."""
    nyq = sample_rate / 2
    b, a = butter(4, max(cutoff_hz, 1) / nyq, btype='high')
    return lfilter(b, a, signal)


def distort_pitch_shift(signal: np.ndarray, semitones: float = 2.0) -> np.ndarray:
    """Crude pitch shift by resampling (changes duration slightly).
    
    Positive semitones = pitch up, negative = pitch down.
    """
    factor = 2.0 ** (semitones / 12.0)
    n_out = int(len(signal) / factor)
    shifted = scipy_resample(signal, n_out)
    # Pad or trim to original length
    if len(shifted) < len(signal):
        shifted = np.pad(shifted, (0, len(signal) - len(shifted)))
    else:
        shifted = shifted[:len(signal)]
    return shifted


def distort_reverb(signal: np.ndarray, decay: float = 0.4,
                   delay_ms: float = 30.0, sample_rate: int = 22050) -> np.ndarray:
    """Add a simple echo/reverb effect."""
    delay_samples = int(delay_ms * sample_rate / 1000)
    result = signal.copy()
    for i in range(1, 5):
        offset = delay_samples * i
        gain = decay ** i
        if offset < len(result):
            end = min(len(result), offset + len(signal))
            result[offset:end] += gain * signal[:end - offset]
    return result


def distort_time_stretch(signal: np.ndarray, factor: float = 1.1) -> np.ndarray:
    """Stretch/compress time without changing pitch (approximate via resampling)."""
    n_out = int(len(signal) * factor)
    stretched = scipy_resample(signal, n_out)
    if len(stretched) < len(signal):
        stretched = np.pad(stretched, (0, len(signal) - len(stretched)))
    else:
        stretched = stretched[:len(signal)]
    return stretched


# ============================================================================
# Embedding
# ============================================================================

def embed_signature(
    background: np.ndarray,
    signature: np.ndarray,
    position_samples: int,
    gain: float = 1.0,
) -> np.ndarray:
    """Embed a signature into a background signal at a given position.
    
    Args:
        background: Background audio signal.
        signature: Signature to embed.
        position_samples: Sample position where to insert signature.
        gain: Amplitude gain for the signature.
    
    Returns:
        Combined signal with signature embedded.
    """
    result = background.copy()
    end = position_samples + len(signature)
    if end > len(result):
        end = len(result)
        sig = signature[:end - position_samples]
    else:
        sig = signature
    result[position_samples:end] += gain * sig
    return result


def generate_rich_background(duration: float, sample_rate: int = 22050,
                             seed: int = 42) -> np.ndarray:
    """Generate a complex, realistic background with multiple interfering sources.
    
    Mixes pink noise, random tonal hum, intermittent sine bursts, and
    low-level cracks/pops — much more challenging than plain white noise.
    """
    rng = np.random.RandomState(seed)
    n = int(sample_rate * duration)
    
    # 1. Pink noise floor
    bg = generate_pink_noise(duration, sample_rate, amplitude=0.06)
    
    # 2. Low-frequency hum (50 Hz mains hum + harmonics)
    t = np.linspace(0, duration, n, endpoint=False)
    hum = 0.02 * np.sin(2 * np.pi * 50 * t)
    hum += 0.01 * np.sin(2 * np.pi * 100 * t)
    hum += 0.005 * np.sin(2 * np.pi * 150 * t)
    bg += hum
    
    # 3. Random intermittent tonal bursts (interfering signals)
    n_bursts = int(duration * 1.5)
    for _ in range(n_bursts):
        burst_freq = rng.uniform(200, 3000)
        burst_dur = rng.uniform(0.05, 0.3)
        burst_amp = rng.uniform(0.01, 0.08)
        burst_start = rng.randint(0, max(1, n - int(burst_dur * sample_rate)))
        burst_samples = int(burst_dur * sample_rate)
        tb = np.linspace(0, burst_dur, burst_samples, endpoint=False)
        burst = burst_amp * np.sin(2 * np.pi * burst_freq * tb)
        # Fade envelope
        env = np.sin(np.pi * tb / burst_dur)
        burst *= env
        end = min(burst_start + burst_samples, n)
        bg[burst_start:end] += burst[:end - burst_start]
    
    # 4. Impulsive pops/clicks
    n_clicks = int(duration * 3)
    for _ in range(n_clicks):
        pos = rng.randint(0, n - 10)
        click_len = rng.randint(1, 8)
        bg[pos:pos + click_len] += rng.uniform(-0.05, 0.05, click_len)
    
    return bg


def create_test_audio_files(output_dir: str, sample_rate: int = 22050) -> dict:
    """Create a comprehensive set of test audio files.

    Produces four signature types and many haystack files of increasing
    difficulty, designed to expose the relative strengths of cross-
    correlation, spectrogram matching, and ML-based search.

    Categories of haystacks
    -----------------------
    *easy*      – clean background, full-amplitude signatures
    *medium*    – pink-noise background, moderate gain reduction
    *hard*      – rich background, low amplitude *plus* distortion
    *adversarial* – rich background, very low amplitude, heavy distortion
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    np.random.seed(42)

    metadata = {}
    sr = sample_rate

    # ==================================================================
    # 1.  SIGNATURES — four very different sound types
    # ==================================================================

    # 1a. Three-tone beep (simple, tonal)
    sig_beep = generate_beep_pattern([440, 880, 1320], 0.1, 0.05, sr)
    _save(out, "signature_beep.wav", sig_beep, sr, metadata,
          extra={'n_samples': len(sig_beep)})

    # 1b. Chirp sweep (broadband, tonal-ish)
    sig_chirp = generate_chirp(200, 2000, 0.3, sr)
    _save(out, "signature_chirp.wav", sig_chirp, sr, metadata,
          extra={'n_samples': len(sig_chirp)})

    # 1c. Complex arpeggio signature (harmonically rich)
    sig_complex = generate_complex_signature(sr)
    _save(out, "signature_complex.wav", sig_complex, sr, metadata,
          extra={'n_samples': len(sig_complex)})

    # 1d. Drum / percussive signature (wideband, impulsive)
    sig_drum = generate_drum_signature(sr)
    _save(out, "signature_drum.wav", sig_drum, sr, metadata,
          extra={'n_samples': len(sig_drum)})

    # ==================================================================
    # 2.  EASY haystacks — quiet white-noise background, full gain
    # ==================================================================

    bg_easy = generate_noise(10.0, sr, amplitude=0.02)

    beep_positions = [int(2.0 * sr), int(5.5 * sr), int(8.0 * sr)]
    _embed_and_save(out, "haystack_with_beep.wav", bg_easy, sig_beep,
                    beep_positions, [1.0]*3, sr, metadata)

    chirp_positions = [int(1.0 * sr), int(6.0 * sr)]
    _embed_and_save(out, "haystack_with_chirp.wav", bg_easy, sig_chirp,
                    chirp_positions, [1.0]*2, sr, metadata)

    # ==================================================================
    # 3.  NOISE ONLY — no signature present (false-positive baseline)
    # ==================================================================
    noise_only = generate_noise(10.0, sr, amplitude=0.05)
    _save(out, "haystack_noise_only.wav", noise_only, sr, metadata)

    rich_noise = generate_rich_background(10.0, sr, seed=99)
    _save(out, "haystack_rich_noise_only.wav", rich_noise, sr, metadata)

    # ==================================================================
    # 4.  MEDIUM haystacks — pink noise, moderate gain reduction
    # ==================================================================

    bg_med = generate_pink_noise(12.0, sr, amplitude=0.05)

    multi_beep = [(int(1.0*sr), 1.0), (int(3.0*sr), 0.7),
                  (int(5.0*sr), 0.5), (int(7.0*sr), 1.0),
                  (int(9.0*sr), 0.3)]
    pos_m, gains_m = zip(*multi_beep)
    _embed_and_save(out, "haystack_multiple.wav", bg_med, sig_beep,
                    list(pos_m), list(gains_m), sr, metadata)

    multi_chirp_med = [(int(2.0*sr), 0.6), (int(6.5*sr), 0.4)]
    pos_cm, gains_cm = zip(*multi_chirp_med)
    _embed_and_save(out, "haystack_chirp_medium.wav", bg_med, sig_chirp,
                    list(pos_cm), list(gains_cm), sr, metadata)

    # Complex signature in pink noise
    complex_med = [(int(1.5*sr), 0.7), (int(5.0*sr), 0.5),
                   (int(8.5*sr), 0.3)]
    pos_xm, gains_xm = zip(*complex_med)
    _embed_and_save(out, "haystack_complex_medium.wav", bg_med,
                    sig_complex, list(pos_xm), list(gains_xm), sr, metadata)

    # ==================================================================
    # 5.  HARD haystacks — rich background + degraded / distorted
    # ==================================================================

    bg_hard = generate_rich_background(15.0, sr, seed=77)

    # 5a. Low-amplitude beep in rich background
    hard_beep = [(int(2.0*sr), 0.15), (int(6.0*sr), 0.10),
                 (int(10.0*sr), 0.20)]
    pos_hb, gains_hb = zip(*hard_beep)
    _embed_and_save(out, "haystack_beep_low_amp.wav", bg_hard, sig_beep,
                    list(pos_hb), list(gains_hb), sr, metadata)

    # 5b. Distorted chirps (clipped + lowpass) in rich background
    sig_chirp_dist = distort_lowpass(distort_clip(sig_chirp, 0.4), 3000, sr)
    hard_chirp = [(int(1.5*sr), 0.25), (int(7.0*sr), 0.20),
                  (int(11.0*sr), 0.15)]
    pos_hc, gains_hc = zip(*hard_chirp)
    _embed_and_save(out, "haystack_chirp_distorted.wav", bg_hard,
                    sig_chirp_dist, list(pos_hc), list(gains_hc), sr,
                    metadata, extra={'distortion': 'clip+lowpass'})

    # 5c. Complex signature with reverb in rich background
    sig_complex_rev = distort_reverb(sig_complex, decay=0.5, delay_ms=25, sample_rate=sr)
    hard_complex = [(int(3.0*sr), 0.20), (int(9.0*sr), 0.15)]
    pos_hx, gains_hx = zip(*hard_complex)
    _embed_and_save(out, "haystack_complex_reverb.wav", bg_hard,
                    sig_complex_rev, list(pos_hx), list(gains_hx), sr,
                    metadata, extra={'distortion': 'reverb'})

    # 5d. Drum signature pitch-shifted + highpassed in rich background
    sig_drum_dp = distort_highpass(distort_pitch_shift(sig_drum, semitones=1.5),
                                   cutoff_hz=300, sample_rate=sr)
    hard_drum = [(int(2.5*sr), 0.30), (int(8.0*sr), 0.20),
                 (int(12.0*sr), 0.15)]
    pos_hd, gains_hd = zip(*hard_drum)
    _embed_and_save(out, "haystack_drum_shifted.wav", bg_hard,
                    sig_drum_dp, list(pos_hd), list(gains_hd), sr,
                    metadata, extra={'distortion': 'pitch_shift+highpass'})

    # ==================================================================
    # 6.  ADVERSARIAL haystack — extremely low amplitude, multiple
    #     distortions, long file, designed to stump cross-correlation
    # ==================================================================

    bg_adv = generate_rich_background(20.0, sr, seed=123)

    # Beep: clipped + reverbed + very quiet
    sig_beep_adv = distort_reverb(distort_clip(sig_beep, 0.35),
                                   decay=0.45, delay_ms=20, sample_rate=sr)
    adv_beep = [(int(3.0*sr), 0.08), (int(9.0*sr), 0.06),
                (int(15.0*sr), 0.10)]
    pos_ab, gains_ab = zip(*adv_beep)
    _embed_and_save(out, "haystack_beep_adversarial.wav", bg_adv,
                    sig_beep_adv, list(pos_ab), list(gains_ab), sr,
                    metadata, extra={'distortion': 'clip+reverb',
                                     'difficulty': 'adversarial'})

    # Complex: time-stretched + lowpassed + very quiet
    sig_complex_adv = distort_lowpass(
        distort_time_stretch(sig_complex, factor=1.08), 2500, sr)
    adv_complex = [(int(4.0*sr), 0.07), (int(12.0*sr), 0.05)]
    pos_ax, gains_ax = zip(*adv_complex)
    _embed_and_save(out, "haystack_complex_adversarial.wav", bg_adv,
                    sig_complex_adv, list(pos_ax), list(gains_ax), sr,
                    metadata, extra={'distortion': 'time_stretch+lowpass',
                                     'difficulty': 'adversarial'})

    return metadata


# ======================================================================
# Private helpers
# ======================================================================

def _save(out: Path, filename: str, data: np.ndarray, sr: int,
          metadata: dict, key: Optional[str] = None,
          extra: Optional[dict] = None) -> str:
    """Save a WAV file and record metadata."""
    path = str(out / filename)
    audio_utils.save_wav(path, data, sr)
    k = key or filename.replace('.wav', '')
    entry: dict = {'path': path, 'duration': len(data) / sr}
    if extra:
        entry.update(extra)
    metadata[k] = entry
    return path


def _embed_and_save(out: Path, filename: str, background: np.ndarray,
                    signature: np.ndarray, positions: list, gains: list,
                    sr: int, metadata: dict, extra: Optional[dict] = None):
    """Embed signature at given positions/gains, save, and record metadata."""
    haystack = background.copy()
    for pos, gain in zip(positions, gains):
        haystack = embed_signature(haystack, signature, pos, gain=gain)
    path = _save(out, filename, haystack, sr, metadata, extra=extra)
    entry = metadata[filename.replace('.wav', '')]
    entry['signature_positions_samples'] = positions
    entry['signature_positions_seconds'] = [p / sr for p in positions]
    entry['gains'] = gains
    return path


if __name__ == "__main__":
    import json
    meta = create_test_audio_files("test_audio")
    print(json.dumps(meta, indent=2, default=str))
    print(f"\nCreated {len(meta)} test audio files successfully!")
