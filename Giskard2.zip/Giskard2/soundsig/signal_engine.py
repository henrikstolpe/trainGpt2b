"""Signal processing engine for finding sound signatures inside other sounds.

Provides cross-correlation based matching, spectrogram fingerprint matching,
and peak detection for locating signature occurrences.
"""

import numpy as np
from scipy import signal
from scipy.ndimage import maximum_filter
from typing import List, Tuple, Optional, NamedTuple
from dataclasses import dataclass


@dataclass
class MatchResult:
    """Result of a signature match search."""
    position_samples: int      # Position in samples from start
    position_seconds: float    # Position in seconds from start
    confidence: float          # Confidence score 0.0 - 1.0
    duration_seconds: float    # Duration of the matched segment


class SignalEngine:
    """Engine for finding sound signatures in audio using signal processing."""

    def __init__(self, sample_rate: int = 22050):
        """Initialize the signal engine.
        
        Args:
            sample_rate: Working sample rate for all operations.
        """
        self.sample_rate = sample_rate

    def cross_correlate(
        self,
        haystack: np.ndarray,
        needle: np.ndarray,
    ) -> np.ndarray:
        """Compute normalized cross-correlation between haystack and needle.
        
        Uses frequency-domain correlation for efficiency.
        
        Args:
            haystack: The longer audio signal to search in.
            needle: The signature/pattern to search for.
        
        Returns:
            Normalized cross-correlation array. Values near 1.0 indicate
            high similarity at that offset.
        """
        if len(needle) > len(haystack):
            raise ValueError("Needle must be shorter than haystack")
        
        if len(needle) == 0 or len(haystack) == 0:
            raise ValueError("Both signals must be non-empty")
        
        # Normalize signals
        haystack_norm = haystack - np.mean(haystack)
        needle_norm = needle - np.mean(needle)
        
        # Full cross-correlation using FFT
        correlation = signal.fftconvolve(haystack_norm, needle_norm[::-1], mode='valid')
        
        # Compute local energy for normalization (sliding window RMS)
        needle_energy = np.sqrt(np.sum(needle_norm ** 2))
        
        # Sliding window energy of haystack
        haystack_sq_cumsum = np.cumsum(haystack_norm ** 2)
        window_len = len(needle)
        
        # Energy in each window position
        window_energy = np.zeros(len(correlation))
        window_energy[0] = haystack_sq_cumsum[window_len - 1]
        if len(correlation) > 1:
            window_energy[1:] = (
                haystack_sq_cumsum[window_len:] - haystack_sq_cumsum[:len(correlation) - 1]
            )
        window_energy = np.sqrt(np.maximum(window_energy, 1e-10))
        
        # Normalize
        norm_factor = window_energy * needle_energy
        norm_factor = np.maximum(norm_factor, 1e-10)  # Avoid division by zero
        normalized_corr = correlation / norm_factor
        
        return np.clip(normalized_corr, -1.0, 1.0)

    def find_matches(
        self,
        haystack: np.ndarray,
        needle: np.ndarray,
        threshold: float = 0.5,
        min_distance_seconds: float = 0.1,
    ) -> List[MatchResult]:
        """Find all occurrences of needle in haystack above threshold.
        
        Args:
            haystack: The longer audio to search in.
            needle: The signature to search for.
            threshold: Minimum correlation threshold (0.0 - 1.0).
            min_distance_seconds: Minimum distance between matches in seconds.
        
        Returns:
            List of MatchResult objects sorted by confidence (descending).
        """
        corr = self.cross_correlate(haystack, needle)
        
        min_distance_samples = int(min_distance_seconds * self.sample_rate)
        needle_duration = len(needle) / self.sample_rate
        
        # Find peaks above threshold
        peaks = self._find_peaks(corr, threshold, min_distance_samples)
        
        results = []
        for pos in peaks:
            results.append(MatchResult(
                position_samples=pos,
                position_seconds=pos / self.sample_rate,
                confidence=float(corr[pos]),
                duration_seconds=needle_duration,
            ))
        
        # Sort by confidence descending
        results.sort(key=lambda r: r.confidence, reverse=True)
        return results

    def _find_peaks(
        self,
        data: np.ndarray,
        threshold: float,
        min_distance: int,
    ) -> List[int]:
        """Find peaks in data above threshold with minimum distance constraint.
        
        Args:
            data: 1D array to find peaks in.
            threshold: Minimum value for a peak.
            min_distance: Minimum distance between peaks in samples.
        
        Returns:
            List of peak indices.
        """
        # Use scipy's find_peaks
        peaks, properties = signal.find_peaks(
            data,
            height=threshold,
            distance=max(1, min_distance),
        )
        return peaks.tolist()

    def compute_spectrogram(
        self,
        audio: np.ndarray,
        n_fft: int = 2048,
        hop_length: int = 512,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Compute spectrogram of audio signal.
        
        Args:
            audio: Input audio signal.
            n_fft: FFT window size.
            hop_length: Hop length between frames.
        
        Returns:
            Tuple of (frequencies, times, spectrogram_magnitude).
        """
        freqs, times, Sxx = signal.spectrogram(
            audio,
            fs=self.sample_rate,
            nperseg=n_fft,
            noverlap=n_fft - hop_length,
            scaling='spectrum',
        )
        return freqs, times, np.abs(Sxx)

    def spectrogram_match(
        self,
        haystack: np.ndarray,
        needle: np.ndarray,
        n_fft: int = 2048,
        hop_length: int = 512,
        threshold: float = 0.5,
    ) -> List[MatchResult]:
        """Find signature using spectrogram-based matching.
        
        Computes spectrograms of both signals and uses 2D cross-correlation
        to find where the needle's spectral pattern appears in the haystack.
        
        Args:
            haystack: The longer audio to search in.
            needle: The signature to search for.
            n_fft: FFT window size.
            hop_length: Hop length.
            threshold: Minimum similarity threshold.
        
        Returns:
            List of MatchResult objects.
        """
        _, _, spec_h = self.compute_spectrogram(haystack, n_fft, hop_length)
        _, _, spec_n = self.compute_spectrogram(needle, n_fft, hop_length)
        
        if spec_n.shape[1] > spec_h.shape[1]:
            raise ValueError("Needle spectrogram is wider than haystack spectrogram")
        
        # 2D normalized cross-correlation along time axis
        # Average correlation across frequency bands
        n_time_positions = spec_h.shape[1] - spec_n.shape[1] + 1
        correlations = np.zeros(n_time_positions)
        
        # Flatten frequency dimension and do sliding window correlation
        spec_n_flat = spec_n.flatten()
        spec_n_norm = spec_n_flat - np.mean(spec_n_flat)
        spec_n_energy = np.sqrt(np.sum(spec_n_norm ** 2))
        
        if spec_n_energy < 1e-10:
            return []
        
        for i in range(n_time_positions):
            window = spec_h[:, i:i + spec_n.shape[1]].flatten()
            window_norm = window - np.mean(window)
            window_energy = np.sqrt(np.sum(window_norm ** 2))
            
            if window_energy < 1e-10:
                correlations[i] = 0.0
            else:
                correlations[i] = np.dot(window_norm, spec_n_norm) / (window_energy * spec_n_energy)
        
        correlations = np.clip(correlations, -1.0, 1.0)
        
        # Find peaks
        min_distance_frames = max(1, spec_n.shape[1] // 2)
        peaks = self._find_peaks(correlations, threshold, min_distance_frames)
        
        needle_duration = len(needle) / self.sample_rate
        
        results = []
        for peak_frame in peaks:
            # Convert frame index back to sample position
            position_samples = peak_frame * hop_length
            results.append(MatchResult(
                position_samples=position_samples,
                position_seconds=position_samples / self.sample_rate,
                confidence=float(correlations[peak_frame]),
                duration_seconds=needle_duration,
            ))
        
        results.sort(key=lambda r: r.confidence, reverse=True)
        return results

    def extract_features(
        self,
        audio: np.ndarray,
        n_mfcc: int = 13,
        n_fft: int = 2048,
        hop_length: int = 512,
    ) -> np.ndarray:
        """Extract MFCC features from audio for ML model input.
        
        Uses a pure scipy/numpy implementation (no librosa dependency).
        Computes mel-frequency cepstral coefficients via:
        1. STFT -> power spectrum
        2. Mel filterbank application  
        3. Log compression
        4. DCT to get cepstral coefficients
        
        Args:
            audio: Input audio signal.
            n_mfcc: Number of MFCC coefficients.
            n_fft: FFT size.
            hop_length: Hop length.
        
        Returns:
            MFCC feature matrix of shape (n_mfcc, n_frames).
        """
        from scipy.fft import dct
        
        # 1. Compute power spectrogram via STFT
        n_mels = 128
        # Pad audio if needed
        if len(audio) < n_fft:
            audio = np.pad(audio, (0, n_fft - len(audio)))
        
        # Frame the signal
        n_frames = 1 + (len(audio) - n_fft) // hop_length
        frames = np.zeros((n_fft, n_frames))
        window = np.hanning(n_fft)
        for i in range(n_frames):
            start = i * hop_length
            frames[:, i] = audio[start:start + n_fft] * window
        
        # FFT
        spectrum = np.fft.rfft(frames, axis=0)
        power_spectrum = np.abs(spectrum) ** 2 / n_fft
        
        # 2. Create mel filterbank
        mel_fb = self._mel_filterbank(n_mels, n_fft, self.sample_rate)
        
        # 3. Apply mel filterbank and take log
        mel_spec = np.dot(mel_fb, power_spectrum)
        mel_spec = np.maximum(mel_spec, 1e-10)
        log_mel = np.log(mel_spec)
        
        # 4. DCT to get MFCCs
        mfccs = dct(log_mel, type=2, axis=0, norm='ortho')[:n_mfcc]
        
        return mfccs

    @staticmethod
    def _mel_filterbank(n_mels: int, n_fft: int, sample_rate: int) -> np.ndarray:
        """Create a mel-scale filterbank matrix.
        
        Args:
            n_mels: Number of mel bands.
            n_fft: FFT size.
            sample_rate: Sample rate.
        
        Returns:
            Filterbank matrix of shape (n_mels, n_fft // 2 + 1).
        """
        def hz_to_mel(hz):
            return 2595.0 * np.log10(1.0 + hz / 700.0)
        
        def mel_to_hz(mel):
            return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)
        
        n_freqs = n_fft // 2 + 1
        low_mel = hz_to_mel(0)
        high_mel = hz_to_mel(sample_rate / 2)
        mel_points = np.linspace(low_mel, high_mel, n_mels + 2)
        hz_points = mel_to_hz(mel_points)
        bin_points = np.floor((n_fft + 1) * hz_points / sample_rate).astype(int)
        
        fb = np.zeros((n_mels, n_freqs))
        for i in range(n_mels):
            left = bin_points[i]
            center = bin_points[i + 1]
            right = bin_points[i + 2]
            
            for j in range(left, center):
                if center > left:
                    fb[i, j] = (j - left) / (center - left)
            for j in range(center, right):
                if right > center:
                    fb[i, j] = (right - j) / (right - center)
        
        return fb

    def extract_feature_vector(
        self,
        audio: np.ndarray,
        n_mfcc: int = 13,
    ) -> np.ndarray:
        """Extract a fixed-size feature vector from audio (for ML classification).
        
        Computes MFCCs and summarizes with mean and std across time.
        
        Args:
            audio: Input audio signal.
            n_mfcc: Number of MFCC coefficients.
        
        Returns:
            Feature vector of shape (n_mfcc * 2,) - mean and std of each MFCC.
        """
        mfccs = self.extract_features(audio, n_mfcc=n_mfcc)
        mean = np.mean(mfccs, axis=1)
        std = np.std(mfccs, axis=1)
        return np.concatenate([mean, std])
