"""ML model for sound signature similarity detection.

Uses scikit-learn MLPClassifier (neural network) to learn to recognize
sound signatures even when distorted, noisy, or transformed.
This is an open-weight model that can be trained and saved/loaded.
"""

import numpy as np
import pickle
from pathlib import Path
from typing import List, Tuple, Optional
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from dataclasses import dataclass

from .signal_engine import SignalEngine


@dataclass 
class MLMatchResult:
    """Result from ML-based signature detection."""
    position_samples: int
    position_seconds: float
    probability: float       # Probability that this window contains the signature
    duration_seconds: float


class SignatureMLModel:
    """ML model for detecting sound signatures using a neural network.
    
    The model is trained on MFCC features extracted from audio windows.
    Positive examples contain the signature; negative examples don't.
    """

    def __init__(
        self,
        sample_rate: int = 22050,
        n_mfcc: int = 13,
        hidden_layers: Tuple[int, ...] = (128, 64, 32),
        max_iter: int = 500,
    ):
        """Initialize the ML model.
        
        Args:
            sample_rate: Working sample rate.
            n_mfcc: Number of MFCC features.
            hidden_layers: Tuple defining hidden layer sizes for the MLP.
            max_iter: Maximum training iterations.
        """
        self.sample_rate = sample_rate
        self.n_mfcc = n_mfcc
        self.engine = SignalEngine(sample_rate)
        self.scaler = StandardScaler()
        self.model = MLPClassifier(
            hidden_layer_sizes=hidden_layers,
            max_iter=max_iter,
            random_state=42,
            early_stopping=True,
            validation_fraction=0.15,
            activation='relu',
            solver='adam',
            learning_rate='adaptive',
        )
        self.is_trained = False

    def _extract_window_features(self, audio_window: np.ndarray) -> np.ndarray:
        """Extract feature vector from a single audio window.
        
        Args:
            audio_window: Audio samples for one window.
        
        Returns:
            Feature vector.
        """
        return self.engine.extract_feature_vector(audio_window, n_mfcc=self.n_mfcc)

    def generate_training_data(
        self,
        signature: np.ndarray,
        background_segments: List[np.ndarray],
        n_augmentations: int = 50,
        noise_levels: List[float] = None,
        gain_range: Tuple[float, float] = (0.3, 1.5),
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Generate training data from a signature and background audio.
        
        Creates positive examples by augmenting the signature with noise and gain
        variations, and negative examples from random background segments.
        
        Args:
            signature: The signature audio to detect.
            background_segments: List of background audio segments (no signature).
            n_augmentations: Number of augmented positive examples to generate.
            noise_levels: Noise levels for augmentation.
            gain_range: Min/max gain for augmentation.
        
        Returns:
            Tuple of (feature_matrix, labels) where labels are 1=signature, 0=not.
        """
        if noise_levels is None:
            noise_levels = [0.0, 0.01, 0.02, 0.05, 0.1]
        
        features = []
        labels = []
        sig_len = len(signature)
        
        # Positive examples: signature with augmentations
        for _ in range(n_augmentations):
            noise_level = np.random.choice(noise_levels)
            gain = np.random.uniform(*gain_range)
            
            augmented = signature * gain
            if noise_level > 0:
                augmented += noise_level * np.random.randn(sig_len)
            
            feat = self._extract_window_features(augmented)
            features.append(feat)
            labels.append(1)
        
        # Negative examples: random windows from background
        for bg in background_segments:
            if len(bg) < sig_len:
                continue
            # Take several random windows from each background
            n_windows = max(1, n_augmentations // len(background_segments))
            for _ in range(n_windows):
                start = np.random.randint(0, len(bg) - sig_len)
                window = bg[start:start + sig_len]
                feat = self._extract_window_features(window)
                features.append(feat)
                labels.append(0)
        
        return np.array(features), np.array(labels)

    def train(
        self,
        signature: np.ndarray,
        background_segments: List[np.ndarray],
        n_augmentations: int = 100,
    ) -> dict:
        """Train the model to detect a specific signature.
        
        Args:
            signature: The signature audio.
            background_segments: Background audio segments for negative examples.
            n_augmentations: Number of augmented training examples.
        
        Returns:
            Dict with training metrics (accuracy, etc).
        """
        X, y = self.generate_training_data(
            signature, background_segments, n_augmentations
        )
        
        # Split into train/test
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train
        self.model.fit(X_train_scaled, y_train)
        self.is_trained = True
        
        # Evaluate
        y_pred = self.model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, y_pred)
        
        return {
            'accuracy': accuracy,
            'n_train': len(X_train),
            'n_test': len(X_test),
            'n_positive': int(np.sum(y == 1)),
            'n_negative': int(np.sum(y == 0)),
            'report': classification_report(y_test, y_pred, output_dict=True),
        }

    def predict(
        self,
        haystack: np.ndarray,
        window_size_samples: int,
        hop_size_samples: Optional[int] = None,
        threshold: float = 0.5,
    ) -> List[MLMatchResult]:
        """Scan haystack with sliding window and predict signature presence.
        
        Args:
            haystack: Audio to scan.
            window_size_samples: Size of each scanning window (should match signature length).
            hop_size_samples: Hop between windows. Defaults to window_size // 4.
            threshold: Minimum probability threshold.
        
        Returns:
            List of MLMatchResult for windows above threshold.
        """
        if not self.is_trained:
            raise RuntimeError("Model must be trained before prediction")
        
        if hop_size_samples is None:
            hop_size_samples = window_size_samples // 4
        
        results = []
        n_windows = (len(haystack) - window_size_samples) // hop_size_samples + 1
        
        if n_windows <= 0:
            return results
        
        # Extract features for all windows
        features = []
        positions = []
        for i in range(n_windows):
            start = i * hop_size_samples
            window = haystack[start:start + window_size_samples]
            feat = self._extract_window_features(window)
            features.append(feat)
            positions.append(start)
        
        X = np.array(features)
        X_scaled = self.scaler.transform(X)
        
        # Get probabilities
        probabilities = self.model.predict_proba(X_scaled)[:, 1]  # Prob of class 1
        
        # Filter by threshold
        for pos, prob in zip(positions, probabilities):
            if prob >= threshold:
                results.append(MLMatchResult(
                    position_samples=pos,
                    position_seconds=pos / self.sample_rate,
                    probability=float(prob),
                    duration_seconds=window_size_samples / self.sample_rate,
                ))
        
        # Merge overlapping detections (keep highest probability)
        results = self._merge_detections(results, window_size_samples)
        results.sort(key=lambda r: r.probability, reverse=True)
        
        return results

    def _merge_detections(
        self,
        detections: List[MLMatchResult],
        window_size: int,
    ) -> List[MLMatchResult]:
        """Merge overlapping detections, keeping the highest probability one.
        
        Args:
            detections: List of detections to merge.
            window_size: Window size in samples.
        
        Returns:
            Merged detections.
        """
        if not detections:
            return []
        
        # Sort by position
        sorted_dets = sorted(detections, key=lambda d: d.position_samples)
        merged = [sorted_dets[0]]
        
        for det in sorted_dets[1:]:
            prev = merged[-1]
            # Check overlap
            if det.position_samples < prev.position_samples + window_size:
                # Keep the one with higher probability
                if det.probability > prev.probability:
                    merged[-1] = det
            else:
                merged.append(det)
        
        return merged

    def save(self, filepath: str) -> None:
        """Save trained model to disk.
        
        Args:
            filepath: Path to save the model (.pkl).
        """
        if not self.is_trained:
            raise RuntimeError("Cannot save untrained model")
        
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        state = {
            'model': self.model,
            'scaler': self.scaler,
            'sample_rate': self.sample_rate,
            'n_mfcc': self.n_mfcc,
            'is_trained': self.is_trained,
        }
        with open(str(path), 'wb') as f:
            pickle.dump(state, f)

    def load(self, filepath: str) -> None:
        """Load a trained model from disk.
        
        Args:
            filepath: Path to the saved model (.pkl).
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Model file not found: {filepath}")
        
        with open(str(path), 'rb') as f:
            state = pickle.load(f)
        
        self.model = state['model']
        self.scaler = state['scaler']
        self.sample_rate = state['sample_rate']
        self.n_mfcc = state['n_mfcc']
        self.is_trained = state['is_trained']
        self.engine = SignalEngine(self.sample_rate)
