"""PySide6 GUI application for Sound Signature Finder.

Provides a graphical interface for:
- Loading signature and target WAV files
- Running cross-correlation, spectrogram, and ML-based searches
- Visualizing waveforms, correlation results, and match positions
- Training and managing ML models
"""

import sys
import os
import tempfile
import numpy as np
from pathlib import Path
from typing import Optional, List

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QGroupBox, QTabWidget,
    QSlider, QSpinBox, QDoubleSpinBox, QTextEdit, QProgressBar,
    QSplitter, QComboBox, QMessageBox, QCheckBox, QStatusBar,
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QFont

# Audio playback — prefer winsound on Windows, fall back to subprocess
try:
    import winsound
    _HAS_WINSOUND = True
except ImportError:
    _HAS_WINSOUND = False

import matplotlib
matplotlib.use('QtAgg')
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from soundsig.audio_utils import load_wav, save_wav, normalize, get_duration, audio_info
from soundsig.signal_engine import SignalEngine, MatchResult
from soundsig.ml_model import SignatureMLModel, MLMatchResult
from soundsig.generate_test_audio import create_test_audio_files


class SearchWorker(QThread):
    """Background thread for running searches."""
    finished = Signal(list, str)  # results, method_name
    progress = Signal(str)
    error = Signal(str)

    def __init__(self, engine, haystack, needle, method, threshold,
                 ml_model=None, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.haystack = haystack
        self.needle = needle
        self.method = method
        self.threshold = threshold
        self.ml_model = ml_model

    def run(self):
        try:
            if self.method == "cross_correlation":
                self.progress.emit("Running cross-correlation search...")
                results = self.engine.find_matches(
                    self.haystack, self.needle, threshold=self.threshold
                )
                self.finished.emit(results, "Cross-Correlation")
            elif self.method == "spectrogram":
                self.progress.emit("Running spectrogram search...")
                results = self.engine.spectrogram_match(
                    self.haystack, self.needle, threshold=self.threshold
                )
                self.finished.emit(results, "Spectrogram")
            elif self.method == "ml":
                if self.ml_model is None or not self.ml_model.is_trained:
                    self.error.emit("ML model not trained. Please train first.")
                    return
                self.progress.emit("Running ML-based search...")
                results = self.ml_model.predict(
                    self.haystack, len(self.needle), threshold=self.threshold
                )
                # Convert MLMatchResult to a compatible format
                converted = []
                for r in results:
                    converted.append(MatchResult(
                        position_samples=r.position_samples,
                        position_seconds=r.position_seconds,
                        confidence=r.probability,
                        duration_seconds=r.duration_seconds,
                    ))
                self.finished.emit(converted, "ML Model")
        except Exception as e:
            self.error.emit(str(e))


class TrainWorker(QThread):
    """Background thread for ML model training."""
    finished = Signal(dict)
    progress = Signal(str)
    error = Signal(str)

    def __init__(self, model, signature, background_segments, n_augmentations, parent=None):
        super().__init__(parent)
        self.model = model
        self.signature = signature
        self.background_segments = background_segments
        self.n_augmentations = n_augmentations

    def run(self):
        try:
            self.progress.emit("Generating training data...")
            self.progress.emit("Training neural network...")
            metrics = self.model.train(
                self.signature, self.background_segments, self.n_augmentations
            )
            self.finished.emit(metrics)
        except Exception as e:
            self.error.emit(str(e))


class WaveformCanvas(FigureCanvas):
    """Matplotlib canvas for displaying waveforms and results."""

    def __init__(self, parent=None, width=10, height=4):
        self.fig = Figure(figsize=(width, height), dpi=100)
        self.fig.set_facecolor('#2b2b2b')
        super().__init__(self.fig)
        self.setParent(parent)

    def plot_waveform(self, data, sr, title="Waveform", matches=None):
        """Plot an audio waveform with optional match markers."""
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ax.set_facecolor('#1e1e1e')

        t = np.arange(len(data)) / sr
        ax.plot(t, data, color='#4fc3f7', linewidth=0.3, alpha=0.8)

        if matches:
            for m in matches:
                confidence = getattr(m, 'confidence', getattr(m, 'probability', 0.5))
                color = self._confidence_color(confidence)
                ax.axvspan(
                    m.position_seconds,
                    m.position_seconds + m.duration_seconds,
                    alpha=0.3, color=color,
                )
                ax.axvline(m.position_seconds, color=color, linewidth=1.5, alpha=0.8)
                label = f"{confidence:.2f}"
                ax.text(
                    m.position_seconds, ax.get_ylim()[1] * 0.9,
                    label, color=color, fontsize=8,
                )

        ax.set_xlabel('Time (s)', color='white')
        ax.set_ylabel('Amplitude', color='white')
        ax.set_title(title, color='white', fontsize=11)
        ax.tick_params(colors='white')
        for spine in ax.spines.values():
            spine.set_color('#555')

        self.fig.tight_layout()
        self.draw()

    def plot_correlation(self, corr, sr, threshold=0.5, title="Correlation"):
        """Plot correlation curve with threshold line."""
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ax.set_facecolor('#1e1e1e')

        t = np.arange(len(corr)) / sr
        ax.plot(t, corr, color='#81c784', linewidth=0.5)
        ax.axhline(threshold, color='#ff8a65', linestyle='--', linewidth=1, label=f'Threshold={threshold}')
        ax.fill_between(t, corr, threshold, where=(corr > threshold), alpha=0.3, color='#81c784')

        ax.set_xlabel('Time (s)', color='white')
        ax.set_ylabel('Correlation', color='white')
        ax.set_title(title, color='white', fontsize=11)
        ax.set_ylim(-0.2, 1.1)
        ax.legend(facecolor='#333', edgecolor='#555', labelcolor='white')
        ax.tick_params(colors='white')
        for spine in ax.spines.values():
            spine.set_color('#555')

        self.fig.tight_layout()
        self.draw()

    def plot_spectrogram(self, audio, sr, title="Spectrogram"):
        """Plot spectrogram of audio."""
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ax.set_facecolor('#1e1e1e')

        ax.specgram(audio, Fs=sr, NFFT=2048, noverlap=1536, cmap='inferno')
        ax.set_xlabel('Time (s)', color='white')
        ax.set_ylabel('Frequency (Hz)', color='white')
        ax.set_title(title, color='white', fontsize=11)
        ax.tick_params(colors='white')

        self.fig.tight_layout()
        self.draw()

    def _confidence_color(self, confidence):
        """Return color based on confidence level."""
        if confidence > 0.8:
            return '#4caf50'  # Green
        elif confidence > 0.6:
            return '#ffeb3b'  # Yellow
        else:
            return '#ff9800'  # Orange

    def clear_plot(self):
        """Clear the canvas."""
        self.fig.clear()
        self.draw()


class SoundSignatureApp(QMainWindow):
    """Main application window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sound Signature Finder")
        self.setMinimumSize(1200, 800)

        # State
        self.signature_data: Optional[np.ndarray] = None
        self.signature_sr: Optional[int] = None
        self.signature_path: Optional[str] = None
        self.haystack_data: Optional[np.ndarray] = None
        self.haystack_sr: Optional[int] = None
        self.haystack_path: Optional[str] = None
        self.engine: Optional[SignalEngine] = None
        self.ml_model: Optional[SignatureMLModel] = None
        self.current_results: List = []
        self.worker = None
        self.train_worker = None
        self._playing: Optional[str] = None  # 'signature' | 'haystack' | None
        self._temp_dir = tempfile.mkdtemp(prefix='soundsig_')

        self._build_ui()
        self._apply_dark_theme()

    def _build_ui(self):
        """Build the user interface."""
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)

        # Top controls
        controls = self._build_controls()
        main_layout.addWidget(controls)

        # Splitter for plots and results
        splitter = QSplitter(Qt.Vertical)

        # Plot area with tabs
        plot_tabs = QTabWidget()
        
        # Haystack waveform
        self.haystack_canvas = WaveformCanvas(width=12, height=3)
        plot_tabs.addTab(self.haystack_canvas, "Haystack Waveform")
        
        # Signature waveform
        self.signature_canvas = WaveformCanvas(width=12, height=3)
        plot_tabs.addTab(self.signature_canvas, "Signature Waveform")
        
        # Correlation plot
        self.corr_canvas = WaveformCanvas(width=12, height=3)
        plot_tabs.addTab(self.corr_canvas, "Correlation")
        
        # Spectrogram
        self.spec_canvas = WaveformCanvas(width=12, height=3)
        plot_tabs.addTab(self.spec_canvas, "Spectrogram")

        splitter.addWidget(plot_tabs)

        # Results log
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout(results_group)
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setFont(QFont("Consolas", 9))
        self.results_text.setMaximumHeight(200)
        results_layout.addWidget(self.results_text)
        splitter.addWidget(results_group)

        main_layout.addWidget(splitter)

        # Status bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumHeight(15)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        main_layout.addWidget(self.progress_bar)

        self.statusBar().showMessage("Ready. Load a signature and haystack WAV file to begin.")

    def _build_controls(self) -> QWidget:
        """Build the control panel."""
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(5, 5, 5, 5)

        # File loading group
        file_group = QGroupBox("Audio Files")
        file_layout = QVBoxLayout(file_group)

        sig_row = QHBoxLayout()
        self.sig_label = QLabel("Signature: (none)")
        self.sig_label.setMaximumWidth(400)
        btn_load_sig = QPushButton("Load Signature")
        btn_load_sig.clicked.connect(self._load_signature)
        self.btn_play_sig = QPushButton("\u25B6 Play")
        self.btn_play_sig.setFixedWidth(70)
        self.btn_play_sig.setEnabled(False)
        self.btn_play_sig.clicked.connect(lambda: self._play_audio('signature'))
        sig_row.addWidget(self.sig_label)
        sig_row.addWidget(btn_load_sig)
        sig_row.addWidget(self.btn_play_sig)
        file_layout.addLayout(sig_row)

        hay_row = QHBoxLayout()
        self.hay_label = QLabel("Haystack: (none)")
        self.hay_label.setMaximumWidth(400)
        btn_load_hay = QPushButton("Load Haystack")
        btn_load_hay.clicked.connect(self._load_haystack)
        self.btn_play_hay = QPushButton("\u25B6 Play")
        self.btn_play_hay.setFixedWidth(70)
        self.btn_play_hay.setEnabled(False)
        self.btn_play_hay.clicked.connect(lambda: self._play_audio('haystack'))
        hay_row.addWidget(self.hay_label)
        hay_row.addWidget(btn_load_hay)
        hay_row.addWidget(self.btn_play_hay)
        file_layout.addLayout(hay_row)

        stop_row = QHBoxLayout()
        self.btn_stop = QPushButton("\u25A0 Stop Playback")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self._stop_playback)
        self.chk_speed_2x = QCheckBox("2\u00d7 Speed")
        self.chk_speed_2x.setToolTip(
            "Play audio at 2\u00d7 speed")
        stop_row.addWidget(self.btn_stop)
        stop_row.addWidget(self.chk_speed_2x)
        file_layout.addLayout(stop_row)

        gen_row = QHBoxLayout()
        btn_gen = QPushButton("Generate Test Files")
        btn_gen.clicked.connect(self._generate_test_files)
        gen_row.addWidget(btn_gen)
        file_layout.addLayout(gen_row)

        layout.addWidget(file_group)

        # Search controls group
        search_group = QGroupBox("Search")
        search_layout = QVBoxLayout(search_group)

        method_row = QHBoxLayout()
        method_row.addWidget(QLabel("Method:"))
        self.method_combo = QComboBox()
        self.method_combo.addItems(["Cross-Correlation", "Spectrogram", "ML Model"])
        method_row.addWidget(self.method_combo)
        search_layout.addLayout(method_row)

        thresh_row = QHBoxLayout()
        thresh_row.addWidget(QLabel("Threshold:"))
        self.threshold_spin = QDoubleSpinBox()
        self.threshold_spin.setRange(0.0, 1.0)
        self.threshold_spin.setSingleStep(0.05)
        self.threshold_spin.setValue(0.5)
        thresh_row.addWidget(self.threshold_spin)
        search_layout.addLayout(thresh_row)

        btn_search = QPushButton("Search")
        btn_search.setStyleSheet("background-color: #4caf50; font-weight: bold; padding: 8px;")
        btn_search.clicked.connect(self._run_search)
        search_layout.addWidget(btn_search)

        layout.addWidget(search_group)

        # ML controls group
        ml_group = QGroupBox("ML Model (Optional)")
        ml_layout = QVBoxLayout(ml_group)

        aug_row = QHBoxLayout()
        aug_row.addWidget(QLabel("Augmentations:"))
        self.aug_spin = QSpinBox()
        self.aug_spin.setRange(20, 500)
        self.aug_spin.setValue(100)
        aug_row.addWidget(self.aug_spin)
        ml_layout.addLayout(aug_row)

        btn_row = QHBoxLayout()
        btn_train = QPushButton("Train Model")
        btn_train.clicked.connect(self._train_model)
        btn_row.addWidget(btn_train)

        btn_save_model = QPushButton("Save Model")
        btn_save_model.clicked.connect(self._save_model)
        btn_row.addWidget(btn_save_model)

        btn_load_model = QPushButton("Load Model")
        btn_load_model.clicked.connect(self._load_model)
        btn_row.addWidget(btn_load_model)
        ml_layout.addLayout(btn_row)

        self.ml_status_label = QLabel("Status: Not trained")
        ml_layout.addWidget(self.ml_status_label)

        layout.addWidget(ml_group)

        return widget

    def _apply_dark_theme(self):
        """Apply dark theme stylesheet."""
        self.setStyleSheet("""
            QMainWindow { background-color: #2b2b2b; }
            QWidget { background-color: #2b2b2b; color: #ddd; }
            QGroupBox {
                border: 1px solid #555;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
            }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }
            QPushButton {
                background-color: #444;
                border: 1px solid #666;
                border-radius: 4px;
                padding: 5px 12px;
                color: #ddd;
            }
            QPushButton:hover { background-color: #555; }
            QPushButton:pressed { background-color: #333; }
            QTextEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                color: #ccc;
            }
            QComboBox {
                background-color: #444;
                border: 1px solid #666;
                border-radius: 3px;
                padding: 3px;
            }
            QComboBox QAbstractItemView { background-color: #444; color: #ddd; }
            QSpinBox, QDoubleSpinBox {
                background-color: #444;
                border: 1px solid #666;
                border-radius: 3px;
                padding: 2px;
            }
            QTabWidget::pane { border: 1px solid #555; }
            QTabBar::tab {
                background-color: #333;
                border: 1px solid #555;
                padding: 6px 12px;
                color: #aaa;
            }
            QTabBar::tab:selected { background-color: #444; color: #fff; }
            QStatusBar { background-color: #333; color: #aaa; }
            QProgressBar {
                border: 1px solid #555;
                background-color: #333;
            }
            QProgressBar::chunk { background-color: #4caf50; }
            QLabel { background-color: transparent; }
        """)

    def _load_signature(self):
        """Load signature WAV file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Signature WAV", "", "WAV Files (*.wav);;All Files (*)"
        )
        if not filepath:
            return

        try:
            self.signature_data, self.signature_sr = load_wav(filepath)
            self.signature_path = filepath
            duration = get_duration(self.signature_data, self.signature_sr)
            name = Path(filepath).name
            self.sig_label.setText(f"Signature: {name} ({duration:.2f}s)")
            self.signature_canvas.plot_waveform(
                self.signature_data, self.signature_sr,
                title=f"Signature: {name}"
            )
            self._ensure_engine()
            self.btn_play_sig.setEnabled(True)
            self.statusBar().showMessage(f"Loaded signature: {name}")
            self._log(f"Loaded signature: {filepath} ({duration:.2f}s, {self.signature_sr}Hz)")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load signature:\n{e}")

    def _load_haystack(self):
        """Load haystack WAV file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Haystack WAV", "", "WAV Files (*.wav);;All Files (*)"
        )
        if not filepath:
            return

        try:
            self.haystack_data, self.haystack_sr = load_wav(filepath)
            self.haystack_path = filepath
            duration = get_duration(self.haystack_data, self.haystack_sr)
            name = Path(filepath).name
            self.hay_label.setText(f"Haystack: {name} ({duration:.2f}s)")
            self.haystack_canvas.plot_waveform(
                self.haystack_data, self.haystack_sr,
                title=f"Haystack: {name}"
            )
            self.spec_canvas.plot_spectrogram(
                self.haystack_data, self.haystack_sr,
                title=f"Spectrogram: {name}"
            )
            self._ensure_engine()
            self.btn_play_hay.setEnabled(True)
            self.statusBar().showMessage(f"Loaded haystack: {name}")
            self._log(f"Loaded haystack: {filepath} ({duration:.2f}s, {self.haystack_sr}Hz)")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load haystack:\n{e}")

    def _ensure_engine(self):
        """Create or update the signal engine based on loaded audio sample rate."""
        sr = self.haystack_sr or self.signature_sr or 22050
        self.engine = SignalEngine(sample_rate=sr)

    def _generate_test_files(self):
        """Generate test audio files for experimentation."""
        dir_path = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if not dir_path:
            return

        try:
            metadata = create_test_audio_files(dir_path)
            self._log("Generated test audio files:")
            for key, info in metadata.items():
                if 'path' in info:
                    self._log(f"  {key}: {info['path']}")
            self.statusBar().showMessage(f"Test files generated in {dir_path}")
            QMessageBox.information(
                self, "Success",
                f"Test audio files generated in:\n{dir_path}\n\n"
                "You can now load these files for testing."
            )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate test files:\n{e}")

    def _run_search(self):
        """Run the selected search method."""
        if self.signature_data is None:
            QMessageBox.warning(self, "Warning", "Please load a signature first.")
            return
        if self.haystack_data is None:
            QMessageBox.warning(self, "Warning", "Please load a haystack first.")
            return

        self._ensure_engine()
        method_map = {
            "Cross-Correlation": "cross_correlation",
            "Spectrogram": "spectrogram",
            "ML Model": "ml",
        }
        method = method_map[self.method_combo.currentText()]
        threshold = self.threshold_spin.value()

        self.progress_bar.setRange(0, 0)
        self.progress_bar.show()
        self.statusBar().showMessage("Searching...")

        self.worker = SearchWorker(
            self.engine, self.haystack_data, self.signature_data,
            method, threshold, self.ml_model
        )
        self.worker.finished.connect(self._on_search_finished)
        self.worker.progress.connect(self._on_search_progress)
        self.worker.error.connect(self._on_search_error)
        self.worker.start()

    def _on_search_finished(self, results, method_name):
        """Handle search completion."""
        self.progress_bar.hide()
        self.current_results = results

        self._log(f"\n--- {method_name} Search Results ---")
        if not results:
            self._log("No matches found.")
            self.statusBar().showMessage("Search complete: no matches found.")
        else:
            self._log(f"Found {len(results)} match(es):")
            for i, m in enumerate(results):
                self._log(
                    f"  [{i+1}] Time: {m.position_seconds:.3f}s | "
                    f"Confidence: {m.confidence:.4f} | "
                    f"Duration: {m.duration_seconds:.3f}s"
                )
            self.statusBar().showMessage(f"Search complete: {len(results)} match(es) found.")

        # Update plots
        self.haystack_canvas.plot_waveform(
            self.haystack_data, self.haystack_sr,
            title=f"Haystack with {method_name} Matches",
            matches=results,
        )

        # Show correlation plot for cross-correlation method
        if method_name == "Cross-Correlation" and self.engine:
            try:
                corr = self.engine.cross_correlate(self.haystack_data, self.signature_data)
                self.corr_canvas.plot_correlation(
                    corr, self.haystack_sr,
                    threshold=self.threshold_spin.value(),
                    title="Normalized Cross-Correlation"
                )
            except Exception:
                pass

    def _on_search_progress(self, message):
        """Handle search progress update."""
        self.statusBar().showMessage(message)

    def _on_search_error(self, message):
        """Handle search error."""
        self.progress_bar.hide()
        QMessageBox.critical(self, "Search Error", message)
        self.statusBar().showMessage("Search failed.")

    def _train_model(self):
        """Train the ML model."""
        if self.signature_data is None:
            QMessageBox.warning(self, "Warning", "Please load a signature first.")
            return
        if self.haystack_data is None:
            QMessageBox.warning(self, "Warning",
                "Please load a haystack WAV (used as background for training).")
            return

        sr = self.haystack_sr
        self.ml_model = SignatureMLModel(
            sample_rate=sr,
            hidden_layers=(128, 64, 32),
            max_iter=500,
        )

        # Use haystack as background segments
        seg_len = len(self.signature_data) * 5
        segments = []
        for i in range(0, len(self.haystack_data) - seg_len, seg_len):
            segments.append(self.haystack_data[i:i + seg_len])
        if not segments:
            segments = [self.haystack_data]

        n_aug = self.aug_spin.value()

        self.progress_bar.setRange(0, 0)
        self.progress_bar.show()
        self.ml_status_label.setText("Status: Training...")

        self.train_worker = TrainWorker(
            self.ml_model, self.signature_data, segments, n_aug
        )
        self.train_worker.finished.connect(self._on_train_finished)
        self.train_worker.progress.connect(self._on_search_progress)
        self.train_worker.error.connect(self._on_train_error)
        self.train_worker.start()

    def _on_train_finished(self, metrics):
        """Handle training completion."""
        self.progress_bar.hide()
        accuracy = metrics['accuracy']
        self.ml_status_label.setText(f"Status: Trained (accuracy: {accuracy:.1%})")
        self._log(f"\n--- ML Model Training Complete ---")
        self._log(f"  Accuracy: {accuracy:.1%}")
        self._log(f"  Training samples: {metrics['n_train']}")
        self._log(f"  Test samples: {metrics['n_test']}")
        self.statusBar().showMessage(f"Model trained with {accuracy:.1%} accuracy")

    def _on_train_error(self, message):
        """Handle training error."""
        self.progress_bar.hide()
        self.ml_status_label.setText("Status: Training failed")
        QMessageBox.critical(self, "Training Error", message)

    def _save_model(self):
        """Save trained ML model."""
        if self.ml_model is None or not self.ml_model.is_trained:
            QMessageBox.warning(self, "Warning", "No trained model to save.")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Model", "signature_model.pkl", "Pickle Files (*.pkl)"
        )
        if not filepath:
            return

        try:
            self.ml_model.save(filepath)
            self._log(f"Model saved to: {filepath}")
            self.statusBar().showMessage(f"Model saved to {filepath}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save model:\n{e}")

    def _load_model(self):
        """Load a trained ML model."""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Model", "", "Pickle Files (*.pkl);;All Files (*)"
        )
        if not filepath:
            return

        try:
            self.ml_model = SignatureMLModel()
            self.ml_model.load(filepath)
            self.ml_status_label.setText("Status: Model loaded")
            self._log(f"Model loaded from: {filepath}")
            self.statusBar().showMessage(f"Model loaded from {filepath}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load model:\n{e}")

    # ------------------------------------------------------------------
    # Audio playback
    # ------------------------------------------------------------------

    def _play_audio(self, which: str):
        """Play the signature or haystack audio.

        Uses winsound on Windows (async, non-blocking) with a temporary
        WAV file written via soundfile.  Calling play while already
        playing stops the previous sound first.
        """
        # Stop any current playback first
        self._stop_playback()

        if which == 'signature':
            data, sr = self.signature_data, self.signature_sr
        elif which == 'haystack':
            data, sr = self.haystack_data, self.haystack_sr
        else:
            return

        if data is None or sr is None:
            return

        # Write a temporary WAV (16-bit PCM, mono)
        # If 2x speed is checked, multiply the sample rate so playback is faster
        playback_sr = sr * 2 if self.chk_speed_2x.isChecked() else sr
        tmp_path = os.path.join(self._temp_dir, f'_play_{which}.wav')
        try:
            save_wav(tmp_path, data, playback_sr)
        except Exception as e:
            QMessageBox.warning(self, "Playback Error",
                                f"Could not write temp file:\n{e}")
            return

        if _HAS_WINSOUND:
            try:
                winsound.PlaySound(
                    tmp_path,
                    winsound.SND_FILENAME | winsound.SND_ASYNC,
                )
                self._playing = which
                self.btn_stop.setEnabled(True)
                speed_note = ' [2\u00d7]' if self.chk_speed_2x.isChecked() else ''
                self.statusBar().showMessage(
                    f"Playing {which}{speed_note}\u2026 (press Stop to end)")
            except Exception as e:
                QMessageBox.warning(self, "Playback Error", str(e))
        else:
            # Fallback for non-Windows (aplay / afplay / ffplay)
            import subprocess, shutil
            for player in ('aplay', 'afplay', 'ffplay'):
                if shutil.which(player):
                    subprocess.Popen([player, tmp_path],
                                     stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
                    self._playing = which
                    self.btn_stop.setEnabled(True)
                    self.statusBar().showMessage(
                        f"Playing {which}…")
                    return
            QMessageBox.warning(self, "Playback Error",
                                "No audio player found (install aplay, "
                                "afplay, or ffplay).")

    def _stop_playback(self):
        """Stop any currently playing audio."""
        if _HAS_WINSOUND:
            try:
                winsound.PlaySound(None, 0)
            except Exception:
                pass
        self._playing = None
        self.btn_stop.setEnabled(False)
        self.statusBar().showMessage("Playback stopped.")

    def _log(self, message: str):
        """Append a message to the results log."""
        self.results_text.append(message)
        # Scroll to bottom
        scrollbar = self.results_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


def main():
    """Launch the Sound Signature Finder GUI."""
    app = QApplication(sys.argv)
    app.setApplicationName("Sound Signature Finder")

    window = SoundSignatureApp()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
