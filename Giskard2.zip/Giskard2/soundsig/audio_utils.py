"""Audio utility functions for WAV file I/O, resampling, and normalization."""

import numpy as np
import soundfile as sf
from pathlib import Path
from typing import Tuple, Optional


def load_wav(filepath: str, target_sr: Optional[int] = None) -> Tuple[np.ndarray, int]:
    """Load a WAV file and return (samples, sample_rate).
    
    Args:
        filepath: Path to WAV file.
        target_sr: If set, resample to this sample rate.
    
    Returns:
        Tuple of (audio_data as float64 numpy array, sample_rate).
    
    Raises:
        FileNotFoundError: If file does not exist.
        ValueError: If file is not a valid audio file.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {filepath}")
    
    try:
        data, sr = sf.read(str(path), dtype='float64')
    except Exception as e:
        raise ValueError(f"Could not read audio file {filepath}: {e}")
    
    # Convert stereo to mono by averaging channels
    if data.ndim > 1:
        data = np.mean(data, axis=1)
    
    # Resample if target_sr is specified and different from native
    if target_sr is not None and target_sr != sr:
        data = resample(data, sr, target_sr)
        sr = target_sr
    
    return data, sr


def save_wav(filepath: str, data: np.ndarray, sample_rate: int) -> None:
    """Save audio data to a WAV file.
    
    Args:
        filepath: Output file path.
        data: Audio data as numpy array.
        sample_rate: Sample rate in Hz.
    """
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), data, sample_rate)


def resample(data: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
    """Resample audio data from orig_sr to target_sr using scipy.
    
    Args:
        data: Input audio samples.
        orig_sr: Original sample rate.
        target_sr: Target sample rate.
    
    Returns:
        Resampled audio data.
    """
    from scipy.signal import resample as scipy_resample
    
    if orig_sr == target_sr:
        return data
    
    num_samples = int(len(data) * target_sr / orig_sr)
    return scipy_resample(data, num_samples)


def normalize(data: np.ndarray) -> np.ndarray:
    """Normalize audio to [-1, 1] range.
    
    Args:
        data: Input audio samples.
    
    Returns:
        Normalized audio data.
    """
    peak = np.max(np.abs(data))
    if peak == 0:
        return data
    return data / peak


def trim_silence(data: np.ndarray, threshold: float = 0.01) -> np.ndarray:
    """Trim leading and trailing silence from audio.
    
    Args:
        data: Input audio samples.
        threshold: Amplitude threshold below which is considered silence.
    
    Returns:
        Trimmed audio data.
    """
    mask = np.abs(data) > threshold
    if not np.any(mask):
        return data  # All silence, return as-is
    
    indices = np.where(mask)[0]
    return data[indices[0]:indices[-1] + 1]


def get_duration(data: np.ndarray, sample_rate: int) -> float:
    """Get duration of audio in seconds.
    
    Args:
        data: Audio samples.
        sample_rate: Sample rate in Hz.
    
    Returns:
        Duration in seconds.
    """
    return len(data) / sample_rate


def audio_info(filepath: str) -> dict:
    """Get info about an audio file without loading all data.
    
    Args:
        filepath: Path to audio file.
    
    Returns:
        Dict with keys: sample_rate, channels, frames, duration.
    """
    info = sf.info(str(filepath))
    return {
        'sample_rate': info.samplerate,
        'channels': info.channels,
        'frames': info.frames,
        'duration': info.duration,
        'format': info.format,
    }
