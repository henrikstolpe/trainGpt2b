"""Entry point for running the GUI: python -m soundsig"""
from soundsig.gui import main

if __name__ == "__main__":
    main()
