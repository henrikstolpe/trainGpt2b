import soundfile as sf
import numpy as np
from scipy import signal as sig

files = {
    'ablue': 'test_audio/ablue.wav',
    'spblue': 'test_audio/spblue.wav',
    'wblue': 'test_audio/wblue.wav',
    'nepblue': 'test_audio/nepblue.wav',
}

for name, f in files.items():
    data, sr = sf.read(f)
    if data.ndim == 2:
        data = data.mean(axis=1)
    
    print(f'\n{"="*60}')
    print(f'=== {name} ({f}) ===')
    print(f'{"="*60}')
    
    # Bandpass filter for blue whale frequencies (10-400 Hz)
    # Blue whale calls are typically 10-100 Hz but these recordings show 
    # dominant energy around 160-260 Hz, so use wider band
    sos = sig.butter(4, [10, 400], btype='band', fs=sr, output='sos')
    filtered = sig.sosfilt(sos, data)
    
    # Compute energy envelope with 50ms frames, 25ms hop
    frame_len = int(sr * 0.05)
    hop_len = int(sr * 0.025)
    n_frames = (len(filtered) - frame_len) // hop_len + 1
    
    energy = np.array([
        np.sqrt(np.mean(filtered[i*hop_len : i*hop_len + frame_len]**2))
        for i in range(n_frames)
    ])
    
    # Smooth energy envelope
    kernel_size = 11
    kernel = np.ones(kernel_size) / kernel_size
    energy_smooth = np.convolve(energy, kernel, mode='same')
    
    # Adaptive threshold
    median_e = np.median(energy_smooth)
    std_e = np.std(energy_smooth)
    threshold = median_e + 1.5 * std_e
    
    print(f'  Energy: median={median_e:.4f}, std={std_e:.4f}, threshold={threshold:.4f}')
    
    # Find regions above threshold
    above = energy_smooth > threshold
    
    # Find onset and offset of each region
    regions = []
    in_region = False
    start_frame = 0
    for i in range(len(above)):
        if above[i] and not in_region:
            in_region = True
            start_frame = i
        elif not above[i] and in_region:
            in_region = False
            regions.append((start_frame, i))
    if in_region:
        regions.append((start_frame, len(above)))
    
    # Merge regions that are close together (within 0.2s)
    merge_gap = int(0.2 / (hop_len / sr))
    merged = []
    for start, end in regions:
        if merged and (start - merged[-1][1]) < merge_gap:
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))
    
    # Filter out very short regions (< 0.1s)
    min_duration_frames = int(0.1 / (hop_len / sr))
    merged = [(s, e) for s, e in merged if (e - s) >= min_duration_frames]
    
    print(f'  Raw regions: {len(regions)}, merged: {len(merged)}')
    
    # Convert to sample positions and show details
    for i, (sf_idx, ef_idx) in enumerate(merged):
        start_sample = sf_idx * hop_len
        end_sample = min(ef_idx * hop_len + frame_len, len(data))
        start_time = start_sample / sr
        end_time = end_sample / sr
        duration = end_time - start_time
        peak_amp = np.max(np.abs(data[start_sample:end_sample]))
        region_rms = np.sqrt(np.mean(data[start_sample:end_sample]**2))
        
        # Add some padding (0.1s before and after)
        pad = int(0.1 * sr)
        padded_start = max(0, start_sample - pad)
        padded_end = min(len(data), end_sample + pad)
        padded_dur = (padded_end - padded_start) / sr
        
        print(f'  Region {i+1}: {start_time:.3f}s - {end_time:.3f}s '
              f'(dur={duration:.3f}s, padded={padded_dur:.3f}s) '
              f'peak={peak_amp:.3f} rms={region_rms:.3f}')
