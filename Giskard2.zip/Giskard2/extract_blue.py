"""
Extract blue whale call signatures from ablue, spblue, wblue, nepblue WAV files.
Saves each detected call as sigbluewhaleN.wav (numbered sequentially across all files).
Also saves a composite (averaged) signature per file.
"""
import soundfile as sf
import numpy as np
from scipy import signal as sig

def detect_whale_calls(data, sr, threshold_factor=1.5, min_dur=0.1, merge_gap_s=0.2, pad_s=0.1):
    """Detect whale call regions using bandpass + energy envelope."""
    # Bandpass filter for whale frequencies
    sos = sig.butter(4, [10, 400], btype='band', fs=sr, output='sos')
    filtered = sig.sosfilt(sos, data)
    
    # Energy envelope
    frame_len = int(sr * 0.05)
    hop_len = int(sr * 0.025)
    n_frames = (len(filtered) - frame_len) // hop_len + 1
    
    energy = np.array([
        np.sqrt(np.mean(filtered[i*hop_len : i*hop_len + frame_len]**2))
        for i in range(n_frames)
    ])
    
    # Smooth
    kernel = np.ones(11) / 11
    energy_smooth = np.convolve(energy, kernel, mode='same')
    
    # Threshold
    median_e = np.median(energy_smooth)
    std_e = np.std(energy_smooth)
    threshold = median_e + threshold_factor * std_e
    
    above = energy_smooth > threshold
    
    # Find regions
    regions = []
    in_region = False
    start_frame = 0
    for i in range(len(above)):
        if above[i] and not in_region:
            in_region = True
            start_frame = i
        elif not above[i] and in_region:
            in_region = False
            regions.append((start_frame, i))
    if in_region:
        regions.append((start_frame, len(above)))
    
    # Merge nearby
    merge_gap = int(merge_gap_s / (hop_len / sr))
    merged = []
    for start, end in regions:
        if merged and (start - merged[-1][1]) < merge_gap:
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))
    
    # Filter short
    min_frames = int(min_dur / (hop_len / sr))
    merged = [(s, e) for s, e in merged if (e - s) >= min_frames]
    
    # Convert to sample ranges with padding
    pad = int(pad_s * sr)
    calls = []
    for sf_idx, ef_idx in merged:
        start_sample = max(0, sf_idx * hop_len - pad)
        end_sample = min(len(data), ef_idx * hop_len + frame_len + pad)
        calls.append((start_sample, end_sample))
    
    return calls


def extract_and_save():
    files = [
        ('ablue', 'test_audio/ablue.wav'),
        ('spblue', 'test_audio/spblue.wav'),
        ('wblue', 'test_audio/wblue.wav'),
        ('nepblue', 'test_audio/nepblue.wav'),
    ]
    
    sig_counter = 1
    all_results = []
    
    for name, filepath in files:
        data, sr = sf.read(filepath)
        if data.ndim == 2:
            data = data.mean(axis=1)
        
        calls = detect_whale_calls(data, sr)
        
        print(f'\n=== {name} ({filepath}) — {len(calls)} whale calls detected ===')
        
        # Extract each call as a separate signature
        call_signals = []
        for i, (start, end) in enumerate(calls):
            call_data = data[start:end].copy()
            call_signals.append(call_data)
            
            # Normalize to 0.9 peak
            peak = np.max(np.abs(call_data))
            if peak > 0:
                call_data_norm = call_data * (0.9 / peak)
            else:
                call_data_norm = call_data
            
            outname = f'test_audio/sigbluewhale{sig_counter}.wav'
            sf.write(outname, call_data_norm, sr, subtype='PCM_16')
            dur = len(call_data) / sr
            print(f'  Saved {outname} — {dur:.3f}s, peak={peak:.3f} (from {name} call {i+1}: '
                  f'{start/sr:.3f}s-{end/sr:.3f}s)')
            
            all_results.append({
                'file': outname,
                'source': name,
                'call_idx': i+1,
                'duration': dur,
                'peak': peak,
            })
            sig_counter += 1
        
        # Create composite (peak-aligned average) for this file
        if call_signals:
            # Find longest call to set composite length
            max_len = max(len(c) for c in call_signals)
            
            # Peak-align all calls
            composite = np.zeros(max_len)
            count = np.zeros(max_len)
            
            for c in call_signals:
                peak_idx = np.argmax(np.abs(c))
                # Align peak to center of composite
                center = max_len // 2
                offset = center - peak_idx
                
                for j in range(len(c)):
                    dst = j + offset
                    if 0 <= dst < max_len:
                        composite[dst] += c[j]
                        count[dst] += 1
            
            # Average where we have data
            mask = count > 0
            composite[mask] /= count[mask]
            
            # Trim silence from edges
            abs_comp = np.abs(composite)
            thresh = np.max(abs_comp) * 0.01
            nonzero = np.where(abs_comp > thresh)[0]
            if len(nonzero) > 0:
                trim_start = max(0, nonzero[0] - int(0.05 * sr))
                trim_end = min(len(composite), nonzero[-1] + int(0.05 * sr))
                composite = composite[trim_start:trim_end]
            
            # Normalize
            peak = np.max(np.abs(composite))
            if peak > 0:
                composite = composite * (0.9 / peak)
            
            comp_name = f'test_audio/sigbluewhale_{name}_composite.wav'
            sf.write(comp_name, composite, sr, subtype='PCM_16')
            print(f'  Saved COMPOSITE {comp_name} — {len(composite)/sr:.3f}s '
                  f'(averaged {len(call_signals)} calls)')
    
    print(f'\n{"="*60}')
    print(f'Total: {sig_counter - 1} individual signatures extracted')
    print(f'Files saved:')
    for r in all_results:
        print(f'  {r["file"]} — {r["duration"]:.3f}s from {r["source"]} (call {r["call_idx"]})')


if __name__ == '__main__':
    extract_and_save()
