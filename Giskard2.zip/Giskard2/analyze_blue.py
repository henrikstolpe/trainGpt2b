import soundfile as sf
import numpy as np

files = ['test_audio/ablue.wav', 'test_audio/spblue.wav', 'test_audio/wblue.wav', 'test_audio/nepblue.wav']

for f in files:
    data, sr = sf.read(f)
    if data.ndim == 2:
        ch = data.shape[1]
        data_mono = data.mean(axis=1)
    else:
        ch = 1
        data_mono = data
    dur = len(data_mono) / sr
    rms = np.sqrt(np.mean(data_mono**2))
    peak = np.max(np.abs(data_mono))
    print(f'=== {f} ===')
    print(f'  SR={sr} Hz, channels={ch}, duration={dur:.2f}s, samples={len(data_mono)}')
    print(f'  RMS={rms:.4f}, peak={peak:.4f}')
    
    # Frequency analysis - find dominant frequencies
    chunk = data_mono[:min(len(data_mono), sr*10)]  # first 10s
    fft = np.fft.rfft(chunk)
    freqs = np.fft.rfftfreq(len(chunk), 1.0/sr)
    mag = np.abs(fft)
    # Find top 5 frequency peaks (above 5 Hz to skip DC)
    mask = freqs > 5
    mag_masked = mag[mask]
    freqs_masked = freqs[mask]
    top_idx = np.argsort(mag_masked)[-5:][::-1]
    top_freqs = [f'{freqs_masked[i]:.1f}Hz' for i in top_idx]
    print(f'  Top freqs: {top_freqs}')
    
    # Energy envelope with larger frames for whale calls (100ms frames)
    frame_len = int(sr * 0.1)
    n_frames = len(data_mono) // frame_len
    energy = np.array([np.sqrt(np.mean(data_mono[i*frame_len:(i+1)*frame_len]**2)) for i in range(n_frames)])
    median_e = np.median(energy)
    std_e = np.std(energy)
    print(f'  Energy envelope: median={median_e:.4f}, std={std_e:.4f}, min={energy.min():.4f}, max={energy.max():.4f}')
    print()
